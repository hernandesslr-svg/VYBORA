# VYBORA Android Base 0.1.1

Android app source in Kotlin + Jetpack Compose. Dark neon design inspired by the approved VYBORA reference.

## Included
- Bottom navigation: Início, Vídeos, Publicar, Lives, Perfil.
- Public video demo cards and local like toggle.
- Creator name opens the profile area.
- Lives screen has explicit non-connected transmission/status actions.
- Profile has tappable Publicações, Seguidores and Seguindo stats. They open dialogs that clearly explain real lists need account/backend integration.
- Edit profile and account buttons provide honest status messages.

## Build
Open this folder in Android Studio or run `./gradlew assembleDebug` with Java 17 and network access to required Gradle/Maven repositories.

## Status
Static source checks passed for the listed interactions. Build and Android-device runtime have NOT been verified in this environment. Video cards are examples; backend, real accounts, uploads, video playback, live streaming, chat and external multistream destinations are not implemented yet.
