package app.vybora.android

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import android.content.ContentResolver
import android.net.Uri

/** Cliente HTTP mínimo para a API VYBORA. Nunca usa senha local como autenticação. */
object VyboraApi {
    data class AuthResult(val username: String, val token: String)

    fun authenticate(register: Boolean, username: String, email: String, password: String): AuthResult {
        val path = if (register) "/api/auth/register" else "/api/auth/login"
        val payload = JSONObject().put("email", email.trim().lowercase()).put("password", password)
        if (register) payload.put("username", username.trim().lowercase())
        val response = request("POST", path, payload)
        val user = response.optJSONObject("user") ?: throw IllegalStateException("Resposta inválida do servidor.")
        val token = response.optString("token")
        val name = user.optString("username")
        if (token.isBlank() || name.isBlank()) throw IllegalStateException("O servidor não retornou uma sessão válida.")
        return AuthResult(name, token)
    }

    fun googleAuthenticate(idToken: String): AuthResult {
        val response = request("POST", "/api/auth/google", JSONObject().put("idToken", idToken))
        val user = response.optJSONObject("user") ?: throw IllegalStateException("Resposta inválida do servidor.")
        val token = response.optString("token"); val name = user.optString("username")
        if (token.isBlank() || name.isBlank()) throw IllegalStateException("O servidor não retornou uma sessão válida.")
        return AuthResult(name, token)
    }

    fun requestPasswordReset(email: String): String = request("POST", "/api/auth/forgot-password", JSONObject().put("email", email.trim().lowercase())).optString("message")

    fun resetPassword(token: String, password: String): String = request("POST", "/api/auth/reset-password", JSONObject().put("token", token).put("password", password)).optString("message")

    fun changePassword(token: String, currentPassword: String, newPassword: String): String = request("POST", "/api/auth/change-password", JSONObject().put("currentPassword", currentPassword).put("newPassword", newPassword), token).optString("message")

    fun search(query: String): JSONObject = request("GET", "/api/search?q=" + URLEncoder.encode(query.trim(), "UTF-8") + "&limit=10")

    fun updateProfile(token: String, displayName: String, bio: String): JSONObject =
        request("PATCH", "/api/users/me", JSONObject().put("displayName", displayName).put("bio", bio), token)

    fun getMyProfile(token: String): JSONObject = request("GET", "/api/auth/me", null, token)

    fun uploadMedia(contentResolver: ContentResolver, uri: Uri, token: String, category: String = "post_media"): JSONObject {
        val mime = contentResolver.getType(uri) ?: throw IllegalStateException("Não foi possível identificar o tipo do arquivo.")
        if (!mime.startsWith("image/") && !mime.startsWith("video/")) throw IllegalStateException("Escolha uma foto ou vídeo.")
        val rawName = uri.lastPathSegment?.substringAfterLast('/')?.takeLast(120)?.ifBlank { "midia" } ?: "midia"
        val encodedName = URLEncoder.encode(rawName, "UTF-8")
        val base = BuildConfig.API_BASE_URL.trim().trimEnd('/')
        val connection = (URL("$base/api/files/upload?category=$category&fileName=$encodedName").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20000; readTimeout = 60000; doOutput = true
            setRequestProperty("Authorization", "Bearer $token")
            setRequestProperty("Content-Type", mime)
            setRequestProperty("X-File-Name", rawName)
            setRequestProperty("Accept", "application/json")
        }
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Não foi possível abrir o arquivo escolhido.")
            input.use { source -> connection.outputStream.use { sink -> source.copyTo(sink) } }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (status !in 200..299) throw IllegalStateException(json.optString("error").ifBlank { "Falha ao enviar mídia (HTTP $status)." })
            return json.optJSONObject("file") ?: throw IllegalStateException("O servidor não confirmou o arquivo enviado.")
        } finally { connection.disconnect() }
    }

    fun createPost(token: String, caption: String, mediaFileId: String, mediaType: String): JSONObject =
        request("POST", "/api/posts", JSONObject().put("caption", caption).put("mediaFileId", mediaFileId).put("mediaType", mediaType), token)

    private fun request(method: String, path: String, body: JSONObject? = null, token: String? = null): JSONObject {
        val base = BuildConfig.API_BASE_URL.trim().trimEnd('/')
        require((base.startsWith("https://") || (base.startsWith("http://127.0.0.1") || base.startsWith("http://localhost") || base.startsWith("http://10.0.2.2") || base.startsWith("http://192.168.") || base.startsWith("http://10.")))) {
            "Backend ainda não configurado. Defina API_BASE_URL no app/build.gradle.kts ou use -PAPI_BASE_URL ao compilar."
        }
        val connection = (URL(base + path).openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = 12000
            readTimeout = 12000
            setRequestProperty("Accept", "application/json")
            if (!token.isNullOrBlank()) setRequestProperty("Authorization", "Bearer $token")
            if (body != null) {
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
        }
        try {
            if (body != null) connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val status = connection.responseCode
            val stream = if (status in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            val json = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
            if (status !in 200..299) throw IllegalStateException(json.optString("error").ifBlank { "Falha na comunicação com o servidor (HTTP $status)." })
            return json
        } catch (e: java.net.SocketTimeoutException) {
            throw IllegalStateException("O servidor demorou para responder. Tente novamente.")
        } catch (e: java.net.UnknownHostException) {
            throw IllegalStateException("Não foi possível encontrar o backend. Verifique a URL e a conexão.")
        } finally {
            connection.disconnect()
        }
    }
}
