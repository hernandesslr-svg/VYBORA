# VYBORA — pacote preparado para teste no Render

Este pacote usa o projeto mais recente `VYBORA-POSTAR-CORRIGIDO.zip`. O código do login Google permanece no app e backend.

## Implantação de teste
1. Envie o conteúdo da pasta `VYBORA` para um repositório GitHub (não envie `.env`, senhas ou chaves privadas).
2. No Render, crie um Blueprint a partir desse repositório e selecione o arquivo `render.yaml`. Ele define o serviço Node e um PostgreSQL gratuito para testes.
3. Quando o Render pedir `GOOGLE_CLIENT_ID`, informe o Client ID OAuth Web já usado no projeto. O backend precisa do mesmo ID que o app usa.
4. Após o deploy, confirme `https://SEU-SERVICO.onrender.com/health`; deve retornar status ok e database connected.
5. Copie a URL HTTPS real para `API_BASE_URL` no `local.properties` local antes de compilar o Android.

## Client ID do Google
O Client ID Web configurado para o app é:
`491553779497-llnliort4rsqu1ijna960e417tpt82rv.apps.googleusercontent.com`

Ele é um identificador público OAuth, não uma senha. Nunca coloque `JWT_SECRET`, senha do banco, tokens ou `.env` no GitHub nem no APK.

## Limites do plano de teste
Os serviços gratuitos podem dormir após inatividade e o banco gratuito do Render tem prazo/limites. Use somente dados de teste. As migrações do banco precisam ser executadas uma vez após criar o banco, usando `npm run migrate` no contexto do serviço `BACKEND` e as variáveis de ambiente do Render.
