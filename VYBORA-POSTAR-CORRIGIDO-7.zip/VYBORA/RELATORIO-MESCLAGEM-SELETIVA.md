# Relatório da mesclagem seletiva — VYBORA

## Base preservada
`VYBORA-INTEGRADO-RAILWAY-20261015.zip`

## Aproveitado de `VYBORA-POSTAR-CORRIGIDO-7.zip`
- `BACKEND/package-lock.json`: incluído porque as dependências da raiz do lockfile correspondem ao `BACKEND/package.json` dos dois projetos.
- `DEPLOY_RAILWAY_VYBORA.md`: incluído como documentação complementar de implantação.

## Decisões de preservação
- Mantido o `app/build.gradle.kts` da base integrada, que usa a URL HTTPS da API Railway como padrão e permite configurar `API_BASE_URL` por propriedade, ambiente ou `local.properties`.
- Mantido o `MainActivity.kt` da base integrada, que preserva o fluxo de login por e-mail e senha sem exigir um botão intermediário.
- Mantido o `.gitignore` da base integrada, que inclui proteção para arquivos de ambiente.
- Mantidos `railway.toml`, `render.yaml`, as cinco migrações e os arquivos de backend da base integrada.
- Não copiados os arquivos Android do ZIP POSTAR-CORRIGIDO-7, pois suas diferenças incluem o endereço local `127.0.0.1:8080` como padrão de API, inadequado para um APK de produção.

## Validação executada
- Confirmado que os dois `BACKEND/package.json` são idênticos.
- Confirmado que as dependências declaradas no `package-lock.json` correspondem às do `package.json`.
- O arquivo ZIP foi reaberto e testado quanto à integridade estrutural.

## Limite
Esta é uma mesclagem seletiva de arquivos com base na comparação de conteúdo. Não significa que o APK ou o backend tenham sido compilados/testados contra um banco de produção nesta etapa.
