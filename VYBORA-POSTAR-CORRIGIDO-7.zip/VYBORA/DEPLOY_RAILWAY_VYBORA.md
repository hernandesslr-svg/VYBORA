# VYBORA — preparação segura para Railway

## Importante
- O endereço público `API_BASE_URL` só pode ser definido depois que a API for implantada e o Railway fornecer a URL HTTPS.
- Não envie `BACKEND/.env`, `local.properties`, senhas, tokens ou `JWT_SECRET` para repositórios públicos.
- O Client ID OAuth Web é um identificador público e pode ser usado no build Android e na variável `GOOGLE_CLIENT_ID` do backend. O segredo JWT e a senha do banco ficam somente no Railway.

## Serviço API
- Root Directory: `BACKEND`
- Build command: `npm install`
- Start command: `npm start`
- Health check path: `/health`
- Adicione um PostgreSQL no Railway e configure `DATABASE_URL` usando a URL privada fornecida pelo Railway.

## Variáveis privadas no Railway
Configure no serviço API:
- `NODE_ENV=production`
- `PORT=8080` (se a plataforma fornecer PORT automaticamente, respeite o valor da plataforma)
- `DATABASE_URL` = URL de conexão do PostgreSQL do Railway
- `JWT_SECRET` = novo segredo aleatório com pelo menos 32 bytes, gerado para produção; não reutilize o segredo local
- `GOOGLE_CLIENT_ID=491553779497-llnliort4rsqu1ijna960e417tpt82rv.apps.googleusercontent.com`
- `DATABASE_SSL` conforme a URL e os requisitos do banco gerenciado
- `CORS_ORIGIN` conforme as origens reais usadas pela aplicação; não deixe `*` se o backend passar a usar credenciais/cookies que exijam origem restrita
- `LOCAL_STORAGE_DIR` = diretório persistente configurado, se usar armazenamento local de mídia

**Mídias:** não presuma que o disco efêmero da API é persistente. Para fotos/vídeos de produção, use armazenamento persistente/objeto e configure backups. A persistência de PostgreSQL não persiste automaticamente arquivos enviados.

## Migrações
Execute `npm run migrate` uma vez contra o PostgreSQL de produção, após conferir a `DATABASE_URL`, antes de testar a API. Não execute migrações contra banco errado.

## Depois de a API estar online
1. Copie a URL pública HTTPS gerada pelo Railway.
2. Compile o Android externamente passando a URL pública e o Client ID Web:
   `API_BASE_URL=https://SUA-API-PUBLICA GOOGLE_WEB_CLIENT_ID=491553779497-llnliort4rsqu1ijna960e417tpt82rv.apps.googleusercontent.com`
3. Teste `/health`, cadastro/login e Google Sign-In com uma conta de teste.

Não use `http://127.0.0.1:8080` em um APK destinado a usuários; esse endereço aponta para o próprio celular do usuário.
