# Publicação do VYBORA na Railway

1. Publique o conteúdo desta pasta no repositório `hernandesslr-svg/VYBORA`, branch `master`, preservando o histórico existente.
2. Na Railway, configure o serviço para usar este repositório e a branch `master`. O arquivo `railway.toml` seleciona `BACKEND/Dockerfile`.
3. Configure `DATABASE_URL` com a conexão PostgreSQL da Railway e `JWT_SECRET` com pelo menos 32 caracteres aleatórios. Configure `GOOGLE_CLIENT_ID` para habilitar login Google e `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASSWORD` e `SMTP_FROM` para recuperação de senha por e-mail.
4. Configure `CORS_ORIGIN` apenas para origens confiáveis quando houver clientes web; o aplicativo Android nativo não depende de CORS. `DATABASE_SSL=false` é adequado para o PostgreSQL privado da Railway; siga a configuração exigida pelo provedor se usar conexão externa.
5. O comando de inicialização executa `npm run migrate` antes de `npm start`. O script registra versões e checksum das migrações e interrompe a inicialização se uma migração já aplicada tiver sido alterada.
6. O endpoint `/health` verifica a conexão ao PostgreSQL.

## Atenção ao armazenamento de mídias

O backend atual grava arquivos em `BACKEND/data/uploads` (ou `LOCAL_STORAGE_DIR`). Esse diretório precisa estar em um volume persistente montado em `/app/data` na Railway; sem volume, arquivos locais podem desaparecer em recriações do serviço. Configure o volume antes de considerar o armazenamento de mídias pronto para produção.

## Android

O valor padrão de `API_BASE_URL` foi ajustado para `https://vybora-production.up.railway.app`. Se o domínio público da API mudar, atualize esse valor ou passe `-PAPI_BASE_URL=https://SEU-DOMINIO`. O login Google no APK também exige `GOOGLE_WEB_CLIENT_ID` durante a compilação e o mesmo ID de cliente web em `GOOGLE_CLIENT_ID` no backend.

Não publique `.env`, tokens, senhas, chaves privadas nem credenciais do banco.
