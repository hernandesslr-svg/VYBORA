-- Link a post to a media file stored on the VYBORA-controlled local filesystem.
-- Safe to apply to existing installations; existing media_url records are preserved.
ALTER TABLE posts ADD COLUMN IF NOT EXISTS media_file_id UUID;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'posts_media_file_id_fkey') THEN
    ALTER TABLE posts ADD CONSTRAINT posts_media_file_id_fkey
      FOREIGN KEY (media_file_id) REFERENCES user_files(id) ON DELETE SET NULL;
  END IF;
END $$;
CREATE INDEX IF NOT EXISTS posts_media_file_id_idx ON posts(media_file_id) WHERE media_file_id IS NOT NULL;
