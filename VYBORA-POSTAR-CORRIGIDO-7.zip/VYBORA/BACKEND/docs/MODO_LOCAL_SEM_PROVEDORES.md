# VYBORA — modo local sem Render e sem Supabase

## O que esta configuração muda

- PostgreSQL padrão é o banco principal; não é necessário usar Supabase.
- `STORAGE_DRIVER=local` (padrão) grava mídias em `BACKEND/data/media` em execução direta, ou `BACKEND/data/media` montado como volume no Docker Compose.
- A API usa armazenamento local autenticado para upload e download; não gera URLs públicas para arquivos locais.
- O adaptador S3 permanece opcional para uma migração futura, mas não é necessário no modo local.
- Nenhuma variável de Render ou Supabase é necessária no modo local.

## Rodar em um computador com Docker

1. Instale Docker Engine/Desktop e o plugin Docker Compose.
2. Entre em `BACKEND` e copie `.env.example` para `.env`.
3. Defina `POSTGRES_PASSWORD` com uma senha forte formada por caracteres URL-safe e substitua o mesmo valor na `DATABASE_URL`. Gere um `JWT_SECRET` aleatório com pelo menos 32 bytes.
4. Rode `docker compose up -d --build`.
5. Rode `docker compose exec api npm run migrate`.
6. Teste `http://localhost:8080/health`; deve responder `status: ok` e `database: connected`.
7. Para encerrar sem apagar os dados, rode `docker compose down`. **Não use `docker compose down -v`**, pois isso remove o volume do banco.

## Rodar pelo Termux sem Docker

Instale Node.js e PostgreSQL pelos pacotes oficiais do Termux. Inicialize e inicie o PostgreSQL conforme o pacote instalado, crie um banco e usuário locais, configure `DATABASE_URL` para `127.0.0.1`, defina `STORAGE_DRIVER=local` e `LOCAL_STORAGE_DIR` para um diretório persistente dentro do projeto. Em seguida, execute `npm install`, `npm run migrate` e `npm start` dentro de `BACKEND`. Os comandos exatos de inicialização do PostgreSQL podem variar conforme a versão do pacote Termux.

## Android

- O emulador Android usa `http://10.0.2.2:8080` para alcançar a máquina host.
- Em um aparelho físico, configure `API_BASE_URL` no `app/build.gradle.kts` para o IP privado do computador na mesma rede, por exemplo `http://192.168.x.x:8080`.
- O HTTP sem TLS está habilitado no manifest apenas para desenvolvimento em rede local. **Não publique esta configuração em produção**: use HTTPS e desative tráfego cleartext antes de distribuir o aplicativo publicamente.

## Backups

`ops/backup-local.sh` cria um dump do PostgreSQL e um arquivo dos conteúdos de mídia, criptografa ambos com `age` e gera SHA-256. Requer `pg_dump`, `age`, `DATABASE_URL` e `AGE_RECIPIENT` (chave pública). A chave privada `age` nunca deve ficar junto dos backups. Armazene uma cópia criptografada em outro aparelho/local e faça teste de restauração. Um backup guardado somente no mesmo dispositivo não protege contra perda ou roubo desse dispositivo.

Este script é manual; ele não configura agendamento sozinho. Antes de aceitar usuários reais, configure execução automática, alertas, cópias independentes e testes periódicos de restauração.

## Limites conhecidos desta entrega

O backend tem rotas para contas, perfis, feed, publicações, curtidas, comentários, seguidores, mensagens, notificações e arquivos. O aplicativo Android atualmente integra cadastro/login e atualização/leitura de perfil; outras telas ainda precisam ser conectadas aos endpoints. O upload/download precisa de integração no cliente Android e de teste ponta a ponta. Não declare o produto pronto para usuários reais só porque a API inicia.
