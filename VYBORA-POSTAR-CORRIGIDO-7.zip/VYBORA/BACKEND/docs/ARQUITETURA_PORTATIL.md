# VYBORA — arquitetura local e portabilidade

## Regra estrutural

O Android fala exclusivamente com a API VYBORA. A API usa PostgreSQL e armazenamento de arquivos em disco local, controlado pelo backend. Render e Supabase não são necessários para desenvolvimento local; a pasta `SUPABASE/` foi mantida apenas como referência histórica e não participa da configuração padrão.

- **Banco:** PostgreSQL padrão, local.
- **Arquivos:** `LOCAL_STORAGE_DIR` (padrão `./data/uploads`). O banco guarda metadados, tamanho e SHA-256.
- **Migrações:** `db/migrations/NNN_nome.sql` em ordem. Não altere migrações já aplicadas; crie uma nova. `npm run migrate` verifica SHA-256.
- **Portabilidade do usuário:** `GET /api/users/me/export` exporta JSON com perfil, dados privados, posts, curtidas, listas de seguidores/seguidos, comentários, mensagens, arquivos e notificações. Os bytes dos arquivos devem ser copiados pelo backup local.

## Rotas de arquivos

- `POST /api/files/upload?category=post_media` — autenticado; envia o corpo binário do arquivo com `Content-Type` e `X-File-Name`.
- `GET /api/files` — lista arquivos da própria conta.
- `GET /api/files/:id/content` — baixa arquivo próprio.
- `DELETE /api/files/:id` — marca para exclusão lógica; mantém os bytes no disco para permitir recuperação manual.
- `POST /api/posts` aceita `mediaFileId` de arquivo `post_media` que pertença ao usuário.
- `GET /api/posts/:id/media` entrega mídia vinculada a uma publicação pública e verifica tamanho e SHA-256.

Tipos permitidos incluem JPEG, PNG, WebP, GIF, MP4, WebM e PDF. A API limita tamanho e controla acesso. Antes de produção, acrescente quotas por usuário, monitoramento de espaço, varredura antimalware quando aplicável e uma política de retenção para exclusão física.

## Desenvolvimento local

1. Instale Node.js 20+ e PostgreSQL 16+ (ou Docker).
2. Configure `BACKEND/.env` a partir de `.env.example`, definindo senha forte do banco e `JWT_SECRET` aleatório com pelo menos 32 caracteres.
3. Inicie o PostgreSQL e crie o banco configurado em `DATABASE_URL`.
4. Em `BACKEND/`, execute `npm install`, `npm run migrate` e `npm start`.
5. Confirme `GET /health` e compile o Android com `API_BASE_URL` apontando para a API local.

No mesmo aparelho Android que executa Termux, o padrão de desenvolvimento é `http://127.0.0.1:8080`. No emulador use `-PAPI_BASE_URL=http://10.0.2.2:8080`. Para outro aparelho na mesma rede, use o IP privado do host. HTTP é permitido apenas no build debug; build release exige HTTPS.

## Segurança e privacidade

- Nunca coloque credenciais PostgreSQL, SMTP, Google ou JWT no APK ou no repositório.
- Senhas são armazenadas como hashes bcrypt. Tokens de sessão são revogados por incremento de `token_version` após troca/recuperação de senha.
- Dados pessoais opcionais ficam em `user_private_profiles`, separados do perfil público.
- O endpoint de exportação inclui mensagens privadas; trate o JSON exportado como dado altamente sensível e configure reautenticação/limites antes de lançamento.
- Login Google exige `GOOGLE_CLIENT_ID` no backend e `GOOGLE_WEB_CLIENT_ID` no build. Recuperação por e-mail exige SMTP real. Sem essas credenciais, esses recursos não entregam uma experiência completa.

## Backup e recuperação

- `ops/backup-local.sh` gera dump do PostgreSQL e cópia das mídias de `LOCAL_STORAGE_DIR`, criptografados com `age`. Exige `DATABASE_URL`, `AGE_RECIPIENT`, `pg_dump` e `age`.
- A chave privada `age` deve ficar separada dos backups.
- Copie os arquivos gerados para outro dispositivo/local. Backup armazenado somente no mesmo aparelho não protege contra perda física do aparelho.
- Faça restauração periódica em um banco e diretório isolados; compare contagens e hashes antes de considerar o backup validado.
- O código não agenda backups automaticamente. Configure agendamento e destino externo antes de receber dados reais.

## Limitações atuais

O backend inclui endpoints de autenticação, publicações, curtidas, comentários, seguidores, mensagens, notificações, exportação e armazenamento local. O Compose Android já envia foto/vídeo e cria uma publicação, mas o feed principal ainda tem cartões ilustrativos e precisa ser conectado à API para renderizar publicações reais. Chat em tempo real, push e lives ainda não estão concluídos. Não considerar pronto para produção antes de testes integrados, HTTPS, backups externos e restauração comprovada.
