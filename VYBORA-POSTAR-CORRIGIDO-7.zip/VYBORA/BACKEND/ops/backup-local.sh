#!/usr/bin/env bash
set -Eeuo pipefail
# Backup consistente do PostgreSQL e dos arquivos locais. A chave privada age deve ficar fora deste aparelho.
: "${DATABASE_URL:?Configure DATABASE_URL}"
: "${AGE_RECIPIENT:?Configure AGE_RECIPIENT com a chave pública age}"
BACKUP_DIR="${BACKUP_DIR:-./backups}"
LOCAL_STORAGE_DIR="${LOCAL_STORAGE_DIR:-./data/uploads}"
command -v pg_dump >/dev/null || { echo "ERRO: pg_dump não instalado." >&2; exit 1; }
command -v age >/dev/null || { echo "ERRO: instale age para criptografar os backups." >&2; exit 1; }
mkdir -p "$BACKUP_DIR" "$LOCAL_STORAGE_DIR"
chmod 700 "$BACKUP_DIR"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
pg_dump "$DATABASE_URL" --format=custom --no-owner --no-acl --file="$TMP/database.dump"
tar -C "$(dirname "$LOCAL_STORAGE_DIR")" -czf "$TMP/media.tar.gz" "$(basename "$LOCAL_STORAGE_DIR")"
age -r "$AGE_RECIPIENT" -o "$BACKUP_DIR/vybora-db-$STAMP.dump.age" "$TMP/database.dump"
age -r "$AGE_RECIPIENT" -o "$BACKUP_DIR/vybora-media-$STAMP.tar.gz.age" "$TMP/media.tar.gz"
(
  cd "$BACKUP_DIR"
  sha256sum "vybora-db-$STAMP.dump.age" "vybora-media-$STAMP.tar.gz.age" > "vybora-$STAMP.sha256"
)
chmod 600 "$BACKUP_DIR"/vybora-*
echo "Backups criptografados criados em: $BACKUP_DIR"
echo "ATENÇÃO: copie-os para outro dispositivo/local e teste a restauração antes de considerar a proteção concluída."
