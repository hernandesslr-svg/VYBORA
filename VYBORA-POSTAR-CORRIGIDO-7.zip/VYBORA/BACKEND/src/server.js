import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import dotenv from 'dotenv';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { randomUUID, randomBytes, createHash } from 'node:crypto';
import { OAuth2Client } from 'google-auth-library';
import nodemailer from 'nodemailer';
import { saveLocalObject, readLocalObject, inspectLocalObject, deleteLocalObject } from './storage.js';

dotenv.config();
const { Pool } = pg;
const app = express();
const port = Number(process.env.PORT || 8080);
const jwtSecret = process.env.JWT_SECRET || '';
if (jwtSecret.length < 32) throw new Error('JWT_SECRET precisa ter pelo menos 32 caracteres aleatórios.');
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL não configurada.');
const googleClient = new OAuth2Client();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined, max: 15, idleTimeoutMillis: 30000 });
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN === '*' ? true : (process.env.CORS_ORIGIN || '').split(',').filter(Boolean), credentials: false }));
app.use(express.json({ limit: '64kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const tokenFor = user => jwt.sign({ sub: user.id, ver: Number(user.token_version || 0) }, jwtSecret, { expiresIn: '7d', issuer: 'vybora-api', audience: 'vybora-app' });
const safeUser = user => ({ id: user.id, username: user.username, email: user.email, displayName: user.display_name, bio: user.bio, avatarUrl: user.avatar_url, verified: user.is_verified, createdAt: user.created_at });
const mailer = () => {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASSWORD) return null;
  return nodemailer.createTransport({ host: process.env.SMTP_HOST, port: Number(process.env.SMTP_PORT || 587), secure: process.env.SMTP_SECURE === 'true', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD } });
};
const hashToken = token => createHash('sha256').update(token).digest('hex');
const makeUsername = (email, suffix = '') => { const base = (email.split('@')[0].toLowerCase().replace(/[^a-z0-9_.]/g, '_').replace(/^[^a-z0-9]+/, '').slice(0, 18) || 'usuario'); return `${base}${suffix}`.slice(0,24); };
const auth = asyncRoute(async (req,res,next) => {
  const value = req.get('authorization') || '';
  if (!value.startsWith('Bearer ')) return res.status(401).json({ error: 'Faça login para continuar.' });
  let payload;
  try {
    payload = jwt.verify(value.slice(7), jwtSecret, { issuer: 'vybora-api', audience: 'vybora-app' });
  } catch {
    return res.status(401).json({ error: 'Sessão inválida ou expirada.' });
  }
  const { rows } = await pool.query('SELECT id, username, email, display_name, bio, avatar_url, is_verified, created_at, token_version FROM users WHERE id=$1', [payload.sub]);
  if (!rows[0] || Number(payload.ver || 0) !== Number(rows[0].token_version || 0)) return res.status(401).json({ error: 'Sessão inválida ou revogada. Entre novamente.' });
  req.user = rows[0]; next();
});
app.get('/health', asyncRoute(async (_req,res) => { await pool.query('SELECT 1'); res.json({ status: 'ok', service: 'vybora-api', database: 'connected' }); }));
app.post('/api/auth/register', asyncRoute(async (req,res) => {
  const username = String(req.body?.username || '').trim().toLowerCase();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!/^[a-z0-9_.]{3,24}$/.test(username)) return res.status(400).json({ error: 'Nome de usuário inválido (3–24 letras, números, ponto ou sublinhado).' });
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'E-mail inválido.' });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: 'A senha deve ter entre 8 e 72 caracteres.' });
  const hash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await pool.query('INSERT INTO users(username,email,password_hash) VALUES($1,$2,$3) RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at,token_version', [username,email,hash]);
    const user = rows[0]; res.status(201).json({ token: tokenFor(user), user: safeUser(user) });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Este e-mail ou nome de usuário já está cadastrado.' });
    throw e;
  }
}));
app.post('/api/auth/login', asyncRoute(async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase(); const password = String(req.body?.password || '');
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  if (!rows[0] || !rows[0].password_hash || !(await bcrypt.compare(password, rows[0].password_hash))) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  res.json({ token: tokenFor(rows[0]), user: safeUser(rows[0]) });
}));
// Google Sign-In: the backend verifies the Google ID token; client-supplied email is never trusted.
app.post('/api/auth/google', asyncRoute(async (req,res) => {
  const idToken = String(req.body?.idToken || '');
  if (!idToken || !process.env.GOOGLE_CLIENT_ID) return res.status(503).json({ error: 'Login Google ainda não configurado pelo administrador.' });
  const ticket = await googleClient.verifyIdToken({ idToken, audience: process.env.GOOGLE_CLIENT_ID });
  const payload = ticket.getPayload();
  if (!payload?.sub || !payload.email || payload.email_verified !== true) return res.status(401).json({ error: 'A conta Google não foi verificada.' });
  const existing = await pool.query('SELECT id,username,email,display_name,bio,avatar_url,is_verified,created_at,google_sub,token_version FROM users WHERE google_sub=$1 OR email=$2 ORDER BY (google_sub=$1) DESC LIMIT 1',[payload.sub,payload.email.toLowerCase()]);
  let user = existing.rows[0];
  if (user) {
    if (user.google_sub && user.google_sub !== payload.sub) return res.status(409).json({ error: 'Esta conta já está vinculada a outro login Google.' });
    const updated = await pool.query('UPDATE users SET google_sub=$1, updated_at=NOW() WHERE id=$2 RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at,token_version',[payload.sub,user.id]); user = updated.rows[0];
  } else {
    let username = makeUsername(payload.email); let suffix = 1;
    while ((await pool.query('SELECT 1 FROM users WHERE username=$1',[username])).rowCount) { username = makeUsername(payload.email, `_${suffix++}`); if (suffix > 1000) throw new Error('Não foi possível reservar um nome de usuário.'); }
    const created = await pool.query('INSERT INTO users(username,email,password_hash,google_sub,display_name,avatar_url) VALUES($1,$2,NULL,$3,$4,$5) RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at,token_version',[username,payload.email.toLowerCase(),payload.sub,String(payload.name || '').slice(0,80),payload.picture || null]); user = created.rows[0];
  }
  res.json({ token: tokenFor(user), user: safeUser(user) });
}));

// Password reset: generic response prevents account enumeration. SMTP must be configured for delivery.
app.post('/api/auth/forgot-password', asyncRoute(async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase();
  try {
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      const transport = mailer();
      if (transport) {
        const found = await pool.query('SELECT id,email FROM users WHERE email=$1',[email]);
        if (found.rowCount) {
          const rawToken = randomBytes(32).toString('base64url');
          await pool.query('UPDATE password_reset_tokens SET used_at=NOW() WHERE user_id=$1 AND used_at IS NULL',[found.rows[0].id]);
          await pool.query("INSERT INTO password_reset_tokens(user_id,token_hash,expires_at) VALUES($1,$2,NOW()+INTERVAL '30 minutes')",[found.rows[0].id,hashToken(rawToken)]);
          const resetUrl = `vybora://reset-password?token=${encodeURIComponent(rawToken)}`;
          await transport.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER, to: found.rows[0].email, subject: 'Recuperação de senha VYBORA', text: `Recebemos um pedido para trocar sua senha. Abra este link em até 30 minutos: ${resetUrl}\nSe não foi você, ignore esta mensagem.` });
        }
      } else console.warn('SMTP não configurado; recuperação por e-mail não enviada.');
    }
  } catch (e) { console.error('Falha no fluxo de recuperação:', e?.message || e); }
  res.json({ message: 'Se existir uma conta com esse e-mail, enviaremos as instruções de recuperação.' });
}));
app.post('/api/auth/reset-password', asyncRoute(async (req,res) => {
  const token = String(req.body?.token || ''); const password = String(req.body?.password || '');
  if (token.length < 20 || password.length < 8 || password.length > 72) return res.status(400).json({ error: 'Token inválido ou senha fora do limite de 8 a 72 caracteres.' });
  const hash = await bcrypt.hash(password,12);
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const tokenRow = await client.query('SELECT id,user_id FROM password_reset_tokens WHERE token_hash=$1 AND used_at IS NULL AND expires_at>NOW() FOR UPDATE', [hashToken(token)]);
    if (!tokenRow.rowCount) { await client.query('ROLLBACK'); return res.status(400).json({ error: 'Link inválido ou expirado. Solicite uma nova recuperação.' }); }
    const userId = tokenRow.rows[0].user_id;
    await client.query('UPDATE users SET password_hash=$1,token_version=token_version+1,updated_at=NOW() WHERE id=$2', [hash,userId]);
    await client.query('UPDATE password_reset_tokens SET used_at=NOW() WHERE user_id=$1 AND used_at IS NULL', [userId]);
    await client.query('COMMIT');
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
  res.json({ message: 'Senha alterada. Entre novamente com a nova senha.' });
}));
app.post('/api/auth/change-password', auth, asyncRoute(async (req,res) => {
  const current = String(req.body?.currentPassword || ''); const next = String(req.body?.newPassword || '');
  if (next.length < 8 || next.length > 72) return res.status(400).json({ error: 'A nova senha deve ter entre 8 e 72 caracteres.' });
  const user = await pool.query('SELECT password_hash FROM users WHERE id=$1',[req.user.id]);
  if (!user.rows[0]?.password_hash || !(await bcrypt.compare(current,user.rows[0].password_hash))) return res.status(401).json({ error: 'Senha atual incorreta. Contas Google sem senha podem definir uma senha pelo fluxo de recuperação.' });
  await pool.query('UPDATE users SET password_hash=$1,token_version=token_version+1,updated_at=NOW() WHERE id=$2',[await bcrypt.hash(next,12),req.user.id]);
  await pool.query('UPDATE password_reset_tokens SET used_at=NOW() WHERE user_id=$1 AND used_at IS NULL',[req.user.id]);
  res.json({ message: 'Senha alterada com sucesso.' });
}));
app.get('/api/auth/me', auth, (req,res) => res.json({ user: safeUser(req.user) }));
app.patch('/api/users/me', auth, asyncRoute(async (req,res) => {
  const displayName = String(req.body?.displayName ?? req.user.display_name).trim().slice(0,80);
  const bio = String(req.body?.bio ?? req.user.bio).trim().slice(0,300);
  const { rows } = await pool.query('UPDATE users SET display_name=$1,bio=$2,updated_at=NOW() WHERE id=$3 RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at', [displayName,bio,req.user.id]);
  res.json({ user: safeUser(rows[0]) });
}));
// Busca global limitada, parametrizada e restrita a perfis e publicações públicas.
app.get('/api/search', asyncRoute(async (req,res) => {
  const q = String(req.query.q || '').trim().replace(/\s+/g, ' ').slice(0, 80);
  const limit = Math.min(Math.max(Number(req.query.limit || 10), 1), 20);
  if (q.length < 2) return res.json({ query: q, users: [], posts: [] });
  const pattern = `%${q.replace(/[\%_]/g, '\\$&')}%`;
  const [users, posts] = await Promise.all([
    pool.query(`SELECT u.id,u.username,u.display_name AS "displayName",u.avatar_url AS "avatarUrl",u.is_verified AS verified,
      (SELECT COUNT(*)::int FROM follows f WHERE f.following_id=u.id) AS followers
      FROM users u WHERE u.username ILIKE $1 ESCAPE '\\' OR u.display_name ILIKE $1 ESCAPE '\\'
      ORDER BY u.is_verified DESC, u.username ASC LIMIT $2`, [pattern, limit]),
    pool.query(`SELECT p.id,p.caption,p.media_type AS "mediaType",p.created_at AS "createdAt",
      json_build_object('id',u.id,'username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url,'verified',u.is_verified) AS author,
      (SELECT COUNT(*)::int FROM post_likes l WHERE l.post_id=p.id) AS likes,
      (SELECT COUNT(*)::int FROM comments c WHERE c.post_id=p.id) AS comments
      FROM posts p JOIN users u ON u.id=p.user_id
      WHERE p.visibility='public' AND p.caption ILIKE $1 ESCAPE '\\'
      ORDER BY p.created_at DESC LIMIT $2`, [pattern, limit])
  ]);
  res.json({ query: q, users: users.rows, posts: posts.rows });
}));

app.get('/api/users/:username', asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT u.id,u.username,u.display_name,u.bio,u.avatar_url,u.is_verified,u.created_at,
    (SELECT COUNT(*)::int FROM follows WHERE following_id=u.id) AS followers,
    (SELECT COUNT(*)::int FROM follows WHERE follower_id=u.id) AS following,
    (SELECT COUNT(*)::int FROM posts WHERE user_id=u.id) AS posts_count
    FROM users u WHERE u.username=$1`, [String(req.params.username).toLowerCase()]);
  if (!rows[0]) return res.status(404).json({ error: 'Usuário não encontrado.' }); res.json({ user: rows[0] });
}));
app.post('/api/users/:id/follow', auth, asyncRoute(async (req,res) => {
  const target = req.params.id; if (target === req.user.id) return res.status(400).json({ error: 'Você não pode seguir a si mesmo.' });
  const exists = await pool.query('SELECT id FROM users WHERE id=$1',[target]); if (!exists.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  const found = await pool.query('SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.id,target]);
  if (found.rowCount) { await pool.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.id,target]); return res.json({ following: false }); }
  await pool.query('INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,target]);
  await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind) VALUES($1,$2,'follow')",[target,req.user.id]);
  res.json({ following: true });
}));
app.get('/api/posts', asyncRoute(async (req,res) => {
  const limit = Math.min(Math.max(Number(req.query.limit || 20),1),50); const before = req.query.before ? String(req.query.before) : null;
  const { rows } = await pool.query(`SELECT p.id,p.caption,CASE WHEN p.media_file_id IS NOT NULL THEN '/api/posts/'||p.id||'/media' ELSE p.media_url END AS "mediaUrl",p.media_type AS "mediaType",p.visibility,p.created_at AS "createdAt",
    json_build_object('id',u.id,'username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url,'verified',u.is_verified) AS author,
    (SELECT COUNT(*)::int FROM post_likes l WHERE l.post_id=p.id) AS likes,
    (SELECT COUNT(*)::int FROM comments c WHERE c.post_id=p.id) AS comments
    FROM posts p JOIN users u ON u.id=p.user_id WHERE p.visibility='public' AND ($2::timestamptz IS NULL OR p.created_at<$2)
    ORDER BY p.created_at DESC LIMIT $1`, [limit,before]); res.json({ posts: rows });
}));
app.post('/api/posts', auth, asyncRoute(async (req,res) => {
  const caption = String(req.body?.caption || '').trim();
  const mediaUrl = req.body?.mediaUrl ? String(req.body.mediaUrl) : null;
  const mediaFileId = req.body?.mediaFileId ? String(req.body.mediaFileId) : null;
  const mediaType = String(req.body?.mediaType || (mediaFileId || mediaUrl ? 'image' : 'text'));
  if (!caption && !mediaFileId && !mediaUrl) return res.status(400).json({ error: 'Adicione texto ou mídia à publicação.' });
  if (caption.length > 2200) return res.status(400).json({ error: 'A legenda ultrapassa 2200 caracteres.' });
  if (!['text','image','video'].includes(mediaType)) return res.status(400).json({ error: 'Tipo de mídia inválido.' });
  if (mediaUrl && !/^https:\/\//i.test(mediaUrl)) return res.status(400).json({ error: 'A URL externa da mídia precisa usar HTTPS.' });
  if (mediaFileId) {
    const file = await pool.query("SELECT id FROM user_files WHERE id=$1 AND owner_id=$2 AND category='post_media' AND status='ready' AND deleted_at IS NULL", [mediaFileId, req.user.id]);
    if (!file.rowCount) return res.status(400).json({ error: 'Mídia não encontrada, não concluída ou não pertence à sua conta.' });
  }
  const { rows } = await pool.query('INSERT INTO posts(user_id,caption,media_url,media_file_id,media_type) VALUES($1,$2,$3,$4,$5) RETURNING id,caption,media_url AS "mediaUrl",media_file_id AS "mediaFileId",media_type AS "mediaType",created_at AS "createdAt"',[req.user.id,caption,mediaUrl,mediaFileId,mediaType]);
  if (mediaFileId) rows[0].mediaUrl = `/api/posts/${rows[0].id}/media`;
  res.status(201).json({ post: { ...rows[0], author: safeUser(req.user), likes: 0, comments: 0 } });
}));

// Public media is available only through an existing public post; private posts require owner auth.
app.get('/api/posts/:id/media', asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT p.user_id,p.visibility,f.object_key,f.content_type,f.original_name,f.size_bytes,f.checksum_sha256
    FROM posts p JOIN user_files f ON f.id=p.media_file_id
    WHERE p.id=$1 AND f.deleted_at IS NULL AND f.status='ready'`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Mídia não encontrada.' });
  let viewerId = null;
  const authHeader = req.get('authorization') || '';
  if (authHeader.startsWith('Bearer ')) {
    try { const payload = jwt.verify(authHeader.slice(7), jwtSecret, { issuer: 'vybora-api', audience: 'vybora-app' }); viewerId = payload.sub; } catch {}
  }
  if (rows[0].visibility !== 'public' && viewerId !== rows[0].user_id) return res.status(404).json({ error: 'Mídia não encontrada.' });
  const obj = await readLocalObject(rows[0].object_key);
  if (obj.sizeBytes !== Number(rows[0].size_bytes) || obj.checksumSha256 !== rows[0].checksum_sha256) return res.status(409).json({ error: 'Falha na verificação de integridade.' });
  res.setHeader('Content-Type', rows[0].content_type);
  res.setHeader('Content-Length', obj.sizeBytes);
  res.setHeader('Cache-Control', rows[0].visibility === 'public' ? 'public, max-age=300' : 'private, no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.send(obj.buffer);
}));
app.post('/api/posts/:id/like', auth, asyncRoute(async (req,res) => {
  const post = await pool.query('SELECT id,user_id FROM posts WHERE id=$1',[req.params.id]); if (!post.rowCount) return res.status(404).json({ error: 'Publicação não encontrada.' });
  const found = await pool.query('SELECT 1 FROM post_likes WHERE user_id=$1 AND post_id=$2',[req.user.id,req.params.id]);
  if (found.rowCount) { await pool.query('DELETE FROM post_likes WHERE user_id=$1 AND post_id=$2',[req.user.id,req.params.id]); return res.json({ liked: false }); }
  await pool.query('INSERT INTO post_likes(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,req.params.id]);
  if (post.rows[0].user_id !== req.user.id) await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'like',$3)",[post.rows[0].user_id,req.user.id,req.params.id]);
  res.json({ liked: true });
}));
app.post('/api/posts/:id/comments', auth, asyncRoute(async (req,res) => {
  const body = String(req.body?.body || '').trim(); if (!body || body.length > 1200) return res.status(400).json({ error: 'O comentário deve ter de 1 a 1200 caracteres.' });
  const post = await pool.query('SELECT user_id FROM posts WHERE id=$1',[req.params.id]); if (!post.rowCount) return res.status(404).json({ error: 'Publicação não encontrada.' });
  const { rows } = await pool.query('INSERT INTO comments(post_id,user_id,body) VALUES($1,$2,$3) RETURNING id,post_id AS "postId",body,created_at AS "createdAt"',[req.params.id,req.user.id,body]);
  if (post.rows[0].user_id !== req.user.id) await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'comment',$3)",[post.rows[0].user_id,req.user.id,req.params.id]);
  res.status(201).json({ comment: { ...rows[0], author: safeUser(req.user) } });
}));
app.get('/api/posts/:id/comments', asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT c.id,c.body,c.created_at AS "createdAt",json_build_object('id',u.id,'username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url) AS author FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=$1 ORDER BY c.created_at ASC LIMIT 100`,[req.params.id]); res.json({ comments: rows });
}));
app.get('/api/messages/:username', auth, asyncRoute(async (req,res) => {
  const other = await pool.query('SELECT id FROM users WHERE username=$1',[String(req.params.username).toLowerCase()]); if (!other.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  const { rows } = await pool.query(`SELECT m.id,m.body,m.created_at AS "createdAt",m.read_at AS "readAt",m.sender_id AS "senderId",m.recipient_id AS "recipientId" FROM messages m WHERE (m.sender_id=$1 AND m.recipient_id=$2) OR (m.sender_id=$2 AND m.recipient_id=$1) ORDER BY m.created_at ASC LIMIT 200`,[req.user.id,other.rows[0].id]);
  await pool.query('UPDATE messages SET read_at=NOW() WHERE sender_id=$1 AND recipient_id=$2 AND read_at IS NULL',[other.rows[0].id,req.user.id]); res.json({ messages: rows });
}));
app.post('/api/messages/:username', auth, asyncRoute(async (req,res) => {
  const body = String(req.body?.body || '').trim(); if (!body || body.length > 5000) return res.status(400).json({ error: 'A mensagem deve ter de 1 a 5000 caracteres.' });
  const recipient = await pool.query('SELECT id FROM users WHERE username=$1',[String(req.params.username).toLowerCase()]); if (!recipient.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  if (recipient.rows[0].id === req.user.id) return res.status(400).json({ error: 'Não é possível enviar mensagem para si mesmo.' });
  const { rows } = await pool.query('INSERT INTO messages(sender_id,recipient_id,body) VALUES($1,$2,$3) RETURNING id,body,created_at AS "createdAt",sender_id AS "senderId",recipient_id AS "recipientId"',[req.user.id,recipient.rows[0].id,body]);
  await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'message',$3)",[recipient.rows[0].id,req.user.id,rows[0].id]); res.status(201).json({ message: rows[0] });
}));
// Dados privados opcionais da própria conta; nunca fazem parte do perfil público.
app.get('/api/users/me/private-profile', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query('SELECT birth_date AS "birthDate",phone_e164 AS "phone",country_code AS "countryCode",locale,updated_at AS "updatedAt" FROM user_private_profiles WHERE user_id=$1',[req.user.id]);
  res.json({ privateProfile: rows[0] || { birthDate: null, phone: null, countryCode: null, locale: null } });
}));
app.patch('/api/users/me/private-profile', auth, asyncRoute(async (req,res) => {
  const birthDate = req.body?.birthDate ? String(req.body.birthDate) : null;
  const phone = req.body?.phone ? String(req.body.phone).trim().slice(0,20) : null;
  const countryCode = req.body?.countryCode ? String(req.body.countryCode).trim().toUpperCase() : null;
  const locale = req.body?.locale ? String(req.body.locale).trim().slice(0,20) : null;
  if (birthDate && !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) return res.status(400).json({ error: 'Data de nascimento inválida; use AAAA-MM-DD.' });
  if (countryCode && !/^[A-Z]{2}$/.test(countryCode)) return res.status(400).json({ error: 'Código do país inválido.' });
  const { rows } = await pool.query(`INSERT INTO user_private_profiles(user_id,birth_date,phone_e164,country_code,locale,updated_at)
    VALUES($1,$2,$3,$4,$5,NOW()) ON CONFLICT(user_id) DO UPDATE SET birth_date=EXCLUDED.birth_date,phone_e164=EXCLUDED.phone_e164,country_code=EXCLUDED.country_code,locale=EXCLUDED.locale,updated_at=NOW()
    RETURNING birth_date AS "birthDate",phone_e164 AS "phone",country_code AS "countryCode",locale,updated_at AS "updatedAt"`,[req.user.id,birthDate,phone,countryCode,locale]);
  res.json({ privateProfile: rows[0] });
}));

// Exportação portátil dos dados da própria conta em JSON (LGPD/data portability).
app.get('/api/users/me/export', auth, asyncRoute(async (req,res) => {
  const id = req.user.id;
  const queries = await Promise.all([
    pool.query('SELECT id,username,email,display_name,bio,avatar_url,is_verified,created_at,updated_at FROM users WHERE id=$1',[id]),
    pool.query('SELECT birth_date,phone_e164,country_code,locale,updated_at FROM user_private_profiles WHERE user_id=$1',[id]),
    pool.query('SELECT id,caption,media_url,media_type,visibility,created_at FROM posts WHERE user_id=$1 ORDER BY created_at',[id]),
    pool.query('SELECT l.post_id,l.created_at FROM post_likes l WHERE l.user_id=$1 ORDER BY l.created_at',[id]),
    pool.query('SELECT f.following_id,f.created_at FROM follows f WHERE f.follower_id=$1 ORDER BY f.created_at',[id]),
    pool.query('SELECT f.follower_id,f.created_at FROM follows f WHERE f.following_id=$1 ORDER BY f.created_at',[id]),
    pool.query('SELECT c.id,c.post_id,c.body,c.created_at FROM comments c WHERE c.user_id=$1 ORDER BY c.created_at',[id]),
    pool.query('SELECT id,sender_id,recipient_id,body,read_at,created_at FROM messages WHERE sender_id=$1 OR recipient_id=$1 ORDER BY created_at',[id]),
    pool.query("SELECT id,category,original_name,content_type,size_bytes,created_at FROM user_files WHERE owner_id=$1 AND deleted_at IS NULL AND status='ready' ORDER BY created_at",[id]),
    pool.query('SELECT id,kind,entity_id,read_at,created_at FROM notifications WHERE recipient_id=$1 ORDER BY created_at',[id])
  ]);
  res.set('Content-Disposition', 'attachment; filename="vybora-dados-pessoais.json"');
  res.json({ formatVersion: 1, exportedAt: new Date().toISOString(), profile: queries[0].rows[0], privateProfile: queries[1].rows[0] || null, posts: queries[2].rows, likes: queries[3].rows, following: queries[4].rows, followers: queries[5].rows, comments: queries[6].rows, messages: queries[7].rows, files: queries[8].rows, notifications: queries[9].rows });
}));

// Local disk media storage. Files are written atomically under LOCAL_STORAGE_DIR; only owner can download.
app.post('/api/files/upload', auth, asyncRoute(async (req,res) => {
  const originalName = String(req.get('x-file-name') || req.query?.fileName || '').trim().split(/[\\/]/).pop();
  const contentType = String(req.get('content-type') || '').toLowerCase();
  const category = String(req.query?.category || 'attachment');
  const allowedTypes = new Set(['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','application/pdf']);
  const chunks=[]; let total=0;
  await new Promise((resolve,reject) => { req.on('data',chunk=>{ total+=chunk.length; if(total>100*1024*1024){ reject(Object.assign(new Error('Arquivo excede 100 MB.'),{status:413})); req.destroy(); } else chunks.push(chunk); }); req.on('end',resolve); req.on('error',reject); });
  if (!originalName || originalName.length>255) return res.status(400).json({error:'Nome de arquivo inválido.'});
  if (!allowedTypes.has(contentType)) return res.status(415).json({error:'Tipo de arquivo não permitido.'});
  if (!['avatar','post_media','document','attachment'].includes(category)) return res.status(400).json({error:'Categoria inválida.'});
  if (total<1 || (category!=='post_media' && total>25*1024*1024)) return res.status(413).json({error:'Arquivo vazio ou acima do limite.'});
  const key=`users/${req.user.id}/${randomUUID()}`; const obj=await saveLocalObject(key,Buffer.concat(chunks),contentType);
  const {rows}=await pool.query("INSERT INTO user_files(owner_id,category,original_name,content_type,object_key,size_bytes,expected_size_bytes,checksum_sha256,status,uploaded_at) VALUES($1,$2,$3,$4,$5,$6,$6,$7,'ready',NOW()) RETURNING id,category,original_name AS \"fileName\",content_type AS \"contentType\",size_bytes AS \"sizeBytes\",checksum_sha256 AS \"checksumSha256\",status,uploaded_at AS \"uploadedAt\"",[req.user.id,category,originalName,contentType,key,obj.sizeBytes,obj.checksumSha256]);
  res.status(201).json({file:rows[0]});
}));
app.get('/api/files', auth, asyncRoute(async (req,res) => { const {rows}=await pool.query("SELECT id,category,original_name AS \"fileName\",content_type AS \"contentType\",size_bytes AS \"sizeBytes\",status,uploaded_at AS \"uploadedAt\",created_at AS \"createdAt\" FROM user_files WHERE owner_id=$1 AND deleted_at IS NULL AND status='ready' ORDER BY created_at DESC LIMIT 200",[req.user.id]); res.json({files:rows}); }));
app.get('/api/files/:id/content', auth, asyncRoute(async (req,res) => { const {rows}=await pool.query("SELECT object_key,content_type,original_name,size_bytes,checksum_sha256 FROM user_files WHERE id=$1 AND owner_id=$2 AND deleted_at IS NULL AND status='ready'",[req.params.id,req.user.id]); if(!rows[0]) return res.status(404).json({error:'Arquivo não encontrado.'}); const obj=await readLocalObject(rows[0].object_key); if(obj.sizeBytes!==Number(rows[0].size_bytes)||obj.checksumSha256!==rows[0].checksum_sha256) return res.status(409).json({error:'Falha na verificação de integridade.'}); res.setHeader('Content-Type',rows[0].content_type); res.setHeader('Content-Disposition',`attachment; filename*=UTF-8''${encodeURIComponent(rows[0].original_name)}`); res.send(obj.buffer); }));
app.delete('/api/files/:id', auth, asyncRoute(async (req,res) => { const {rows}=await pool.query('UPDATE user_files SET deleted_at=NOW() WHERE id=$1 AND owner_id=$2 AND deleted_at IS NULL RETURNING object_key',[req.params.id,req.user.id]); if(!rows[0]) return res.status(404).json({error:'Arquivo não encontrado.'}); res.status(204).end(); }));
app.post('/api/files/:id/restore', auth, asyncRoute(async (req,res) => { const {rows}=await pool.query("SELECT object_key,size_bytes,checksum_sha256 FROM user_files WHERE id=$1 AND owner_id=$2 AND deleted_at IS NOT NULL AND status='ready'",[req.params.id,req.user.id]); if(!rows[0]) return res.status(404).json({error:'Arquivo recuperável não encontrado.'}); const obj=await inspectLocalObject(rows[0].object_key); if(obj.sizeBytes!==Number(rows[0].size_bytes)||obj.checksumSha256!==rows[0].checksum_sha256) return res.status(409).json({error:'Arquivo não passou na verificação de integridade.'}); await pool.query('UPDATE user_files SET deleted_at=NULL WHERE id=$1 AND owner_id=$2',[req.params.id,req.user.id]); res.json({ok:true,restored:true}); }));

app.get('/api/notifications', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT n.id,n.kind,n.entity_id AS "entityId",n.read_at AS "readAt",n.created_at AS "createdAt",json_build_object('username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url) AS actor FROM notifications n LEFT JOIN users u ON u.id=n.actor_id WHERE n.recipient_id=$1 ORDER BY n.created_at DESC LIMIT 100`,[req.user.id]); res.json({ notifications: rows });
}));
app.post('/api/notifications/read', auth, asyncRoute(async (req,res) => { await pool.query('UPDATE notifications SET read_at=NOW() WHERE recipient_id=$1 AND read_at IS NULL',[req.user.id]); res.json({ ok: true }); }));
app.use((req,res) => res.status(404).json({ error: 'Rota não encontrada.' }));
app.use((err,req,res,_next) => { console.error('API error:', err?.message || err); res.status(500).json({ error: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor.' : (err?.message || 'Erro interno.') }); });
// Banco atualizado explicitamente com `npm run migrate` durante o deploy;
// a API não altera o schema automaticamente ao iniciar.

app.listen(port, '0.0.0.0', () => console.log(`VYBORA API listening on ${port}`));
process.on('SIGTERM', async () => { await pool.end(); process.exit(0); });
process.on('SIGINT', async () => { await pool.end(); process.exit(0); });
