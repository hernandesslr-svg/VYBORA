import { mkdir, writeFile, readFile, stat, unlink } from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
const root = path.resolve(process.env.LOCAL_STORAGE_DIR || './data/uploads');
function resolveKey(key) { const safe=String(key||'').replace(/\\/g,'/'); if (!safe || safe.startsWith('/') || safe.split('/').some(p=>!p || p==='.' || p==='..')) throw new Error('Chave de arquivo inválida.'); const target=path.resolve(root,safe); if (!target.startsWith(root+path.sep)) throw new Error('Caminho de arquivo inválido.'); return target; }
export async function saveLocalObject(key,buffer,contentType) { const target=resolveKey(key); await mkdir(path.dirname(target),{recursive:true}); const tmp=target+'.'+randomUUID()+'.tmp'; await writeFile(tmp,buffer,{flag:'wx',mode:0o600}); await import('node:fs/promises').then(fs=>fs.rename(tmp,target)); return {sizeBytes:buffer.length,checksumSha256:createHash('sha256').update(buffer).digest('hex'),contentType}; }
export async function readLocalObject(key) { const target=resolveKey(key); const buffer=await readFile(target); return {buffer,sizeBytes:buffer.length,checksumSha256:createHash('sha256').update(buffer).digest('hex')}; }
export async function inspectLocalObject(key) { const obj=await readLocalObject(key); return {sizeBytes:obj.sizeBytes,checksumSha256:obj.checksumSha256}; }
export async function deleteLocalObject(key) { await unlink(resolveKey(key)); }
