# Backend VYBORA — Node.js + PostgreSQL local

API REST Express para a VYBORA. A configuração recomendada deste pacote usa PostgreSQL local e armazenamento de arquivos em disco. Supabase e Render não são necessários para desenvolvimento local.

## Rotas implementadas

- `GET /health`: verifica API e banco.
- `POST /api/auth/register`, `POST /api/auth/login`, `GET /api/auth/me`.
- `PATCH /api/users/me`, `GET /api/users/:username`, `POST /api/users/:id/follow`.
- `GET /api/posts`, `POST /api/posts`, `POST /api/posts/:id/like`.
- `GET/POST /api/posts/:id/comments`.
- `GET/POST /api/messages/:username`.
- `GET /api/notifications`, `POST /api/notifications/read`.
- `GET/PATCH /api/users/me/private-profile`: campos pessoais opcionais e privados.
- `GET /api/users/me/export`: exporta dados da própria conta em JSON.
- `POST /api/files/upload`, `GET /api/files`, `GET /api/files/:id/content`, `DELETE /api/files/:id`: arquivos guardados no disco local do backend.
- `GET /api/posts/:id/media`: entrega mídia vinculada a publicação pública, verificando tamanho e SHA-256.
- `npm run migrate`: aplica migrações numeradas e verifica checksum.

## Portabilidade antes de tudo

O backend usa PostgreSQL padrão e armazenamento local em disco. Supabase e storage S3 não são necessários no modo local. Para detalhes de migração entre fornecedores, arquivos privados e exportação de dados, leia `docs/ARQUITETURA_PORTATIL.md`. As migrações ficam em `db/migrations/` e são aplicadas explicitamente com `npm run migrate`; a API não altera o banco automaticamente ao iniciar.

## Uso opcional de banco gerenciado (não necessário para o modo local)

Siga `../SUPABASE/README_CONFIGURACAO.md`. O resumo é:
1. Crie o projeto Supabase manualmente no dashboard.
2. Para a instalação inicial no Supabase, execute `SUPABASE/01_schema.sql` no SQL Editor. Para instalações controladas pelo backend, prefira `npm run migrate` com a connection string configurada.
3. Configure uma connection string PostgreSQL gerenciada apenas se optar por isso.
4. Publique a API atrás de HTTPS antes de uso público.
5. Teste `/health` e configure `API_BASE_URL` no Android.

Nunca coloque a senha do banco ou uma chave `service_role` no aplicativo Android.

## Usar localmente com Docker

1. Copie `.env.example` para `.env`.
2. Defina `POSTGRES_PASSWORD` e `JWT_SECRET` com valores fortes.
3. Execute `docker compose up -d --build`.
4. A API fica na porta 8080. Em produção, coloque-a atrás de HTTPS e não exponha PostgreSQL.

## Estado real e limitações

- A API tem autenticação própria com bcrypt e JWT e endpoints para contas, publicações, curtidas, comentários, seguidores, mensagens e notificações.
- O projeto Supabase ainda precisa ser criado na conta do proprietário e a API ainda precisa ser hospedada. Este ZIP não contém credenciais nem um serviço já publicado.
- O app Android está ligado ao backend para cadastro/login. As outras telas não estão todas ligadas aos endpoints.
- Upload de foto/vídeo e criação de publicação usam a API local; o feed Compose ainda exibe cartões ilustrativos e precisa ser conectado ao endpoint de feed. Chat em tempo real, notificações push e lives ainda precisam de integrações adicionais.
- Antes do lançamento, use backups, monitoramento, HTTPS, proteção contra abuso e testes de restauração.

## Variáveis

Veja `.env.example` para Docker local. Para executar sem Docker, instale PostgreSQL e defina DATABASE_URL, JWT_SECRET e LOCAL_STORAGE_DIR no ambiente.

## Backups e integridade de arquivos

- Aplique novas migrações com `npm run migrate`; migrações já aplicadas não devem ser editadas.
- O upload local recebe o arquivo bruto em `POST /api/files/upload?category=post_media` com `Content-Type` de imagem/vídeo e cabeçalho `X-File-Name`; a API grava o arquivo, calcula SHA-256 e retorna o identificador. Para publicar, envie `mediaFileId` e `mediaType` a `POST /api/posts`. Aplique todas as migrações com `npm run migrate`.
- Configure backup automático do banco e versionamento/replicação no armazenamento. O script `ops/backup-database.sh` produz dump criptografado com `age`; consulte `docs/ARQUITETURA_PORTATIL.md`.
- Não use com usuários reais antes de configurar e testar restauração do banco e dos objetos.


## Autenticação Google e recuperação de senha

- Execute `npm install` e aplique as migrações com `npm run migrate`.
- Para login Google, configure `GOOGLE_CLIENT_ID` no backend com o OAuth Web Client ID e configure o mesmo valor em `GOOGLE_WEB_CLIENT_ID` no `app/build.gradle.kts`. O backend verifica o ID token assinado pelo Google; nunca confie apenas no e-mail enviado pelo aplicativo.
- Para recuperação de senha, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD` e `SMTP_FROM`. O link é um deep link `vybora://reset-password` e abre a tela de nova senha no app instalado. Sem SMTP, o endpoint responde de forma genérica, mas não entrega o e-mail.
- A senha pode ser alterada em Configurações → Segurança da conta; a recuperação usa token aleatório de uso único, armazenado como hash e válido por 30 minutos.
- O Android declara câmera, microfone e notificações, mas solicita câmera/microfone somente quando a pessoa toca para configurar uma live. Não solicitamos todas as permissões indiscriminadamente; mídia escolhida pelo usuário deve usar o seletor de fotos do Android sempre que possível.


## Autenticação Google e recuperação de senha

- Execute `npm install` e aplique as migrações com `npm run migrate`.
- Para login Google, configure `GOOGLE_CLIENT_ID` no backend com o OAuth Web Client ID e configure o mesmo valor em `GOOGLE_WEB_CLIENT_ID` no `app/build.gradle.kts`. O backend verifica o ID token assinado pelo Google; nunca confie apenas no e-mail enviado pelo aplicativo.
- Para recuperação de senha, configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASSWORD` e `SMTP_FROM`. O link é um deep link `vybora://reset-password` e abre a tela de nova senha no app instalado. Sem SMTP, o endpoint responde de forma genérica, mas não entrega o e-mail.
- A senha pode ser alterada em Configurações → Segurança da conta; a recuperação usa token aleatório de uso único, armazenado como hash e válido por 30 minutos.
- O Android declara câmera, microfone e notificações, mas solicita câmera/microfone somente quando a pessoa toca para configurar uma live. Não solicitamos todas as permissões indiscriminadamente; mídia escolhida pelo usuário deve usar o seletor de fotos do Android sempre que possível.
