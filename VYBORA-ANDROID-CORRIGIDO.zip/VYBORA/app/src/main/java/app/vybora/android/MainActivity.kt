package app.vybora.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF050711)
private val Panel = Color(0xFF111528)
private val Violet = Color(0xFF8B35FF)
private val Pink = Color(0xFFFF2A9D)
private val Muted = Color(0xFFADB2CB)

private data class ClipItem(val creator: String, val title: String, val views: String, val emoji: String, val colors: List<Color>)
private val clips = listOf(
    ClipItem("@mundoselvagem", "Lugares que parecem outro planeta", "12,4 mil", "🏞️", listOf(Color(0xFFEC8A9D), Color(0xFF334F8A))),
    ClipItem("@darkvibes", "Ranked com a galera!", "8,7 mil", "🎮", listOf(Color(0xFF6518A8), Color(0xFF102A72))),
    ClipItem("@cozinhadalu", "Receita rápida de hoje", "5,3 mil", "🍜", listOf(Color(0xFFFF8B55), Color(0xFF8B255F))),
    ClipItem("@gatodigital", "Olha quem apareceu 😂", "3,9 mil", "🐱", listOf(Color(0xFFCA9D72), Color(0xFF4B355E)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VyboraApp() }
    }
}

@Composable
private fun VyboraApp() {
    var tab by remember { mutableIntStateOf(1) }
    var liked by remember { mutableStateOf(setOf<String>()) }
    var notice by remember { mutableStateOf("") }
    var profileStat by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Pink, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Color(0xFF080B16), contentColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Vídeos") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2; notice = "Publicação: a seleção e o envio de vídeos serão conectados na próxima etapa." }, icon = { Icon(Icons.Default.Add, null) }, label = { Text("Publicar") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Radio, null) }, label = { Text("Lives") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Perfil") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall) }
                    Column(Modifier.padding(start = 10.dp).weight(1f)) {
                        Text("VYBORA", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("Lives e vídeos curtos. Pra todo mundo.", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                    Icon(Icons.Default.Search, contentDescription = "Buscar", tint = Color.White, modifier = Modifier.size(25.dp).clickable { notice = "Busca global será conectada quando houver backend." })
                }
                if (notice.isNotBlank()) {
                    Surface(color = Color(0xFF25143A), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(notice, Modifier.weight(1f), color = Color.White, style = MaterialTheme.typography.bodySmall); Text("×", Modifier.clickable { notice = "" }.padding(start = 12.dp), color = Pink) }
                    }
                }
                when (tab) {
                    0 -> SimplePage("Seu mundo, sem limites.", "Descubra criadores, acompanhe as lives e encontre novos vídeos.", "Explorar vídeos") { tab = 1 }
                    1 -> VideoFeed(liked = liked, onLike = { creator -> liked = if (creator in liked) liked - creator else liked + creator }, onProfile = { tab = 4 })
                    2 -> SimplePage("Criar publicação", "A publicação real exige seleção de arquivo, upload e armazenamento. Essa conexão ainda não está habilitada nesta base.", "Entendi") { notice = "Etapa de upload ainda pendente."; tab = 1 }
                    3 -> LivePage(onNotice = { notice = it })
                    else -> ProfilePage(onNotice = { notice = it }, onStat = { profileStat = it })
                }
            }
        }
        if (profileStat.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { profileStat = "" },
                title = { Text(profileStat) },
                text = { Text(if (profileStat == "Seguidores") "Ainda não há seguidores reais. A lista aparecerá aqui quando as contas e o backend forem conectados." else if (profileStat == "Seguindo") "Você ainda não segue nenhuma conta nesta versão de demonstração." else "Ainda não há publicações reais nesta conta.") },
                confirmButton = { TextButton(onClick = { profileStat = "" }) { Text("Fechar") } }
            )
        }
    }
}

@Composable
private fun ProfilePage(onNotice: (String) -> Unit, onStat: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Seu perfil", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black) }
                Text("@seu_usuario", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Perfil de demonstração", color = Muted)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ProfileStat("Publicações", "0") { onStat("Publicações") }
                    ProfileStat("Seguidores", "0") { onStat("Seguidores") }
                    ProfileStat("Seguindo", "0") { onStat("Seguindo") }
                }
                Button(onClick = { onNotice("Editar perfil ficará disponível após a implementação de cadastro e armazenamento de conta.") }, modifier = Modifier.fillMaxWidth()) { Text("Editar perfil") }
                OutlinedButton(onClick = { onNotice("Login e cadastro ainda não estão conectados ao backend.") }, modifier = Modifier.fillMaxWidth()) { Text("Entrar / criar conta") }
            }
        }
        Text("Toque em Seguidores ou Seguindo para abrir a respectiva lista. Nesta base, as listas ainda não contêm usuários reais.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ProfileStat(label: String, count: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(count, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Pink)
        Text(label, style = MaterialTheme.typography.labelMedium, color = Color.White)
    }
}

@Composable
private fun VideoFeed(liked: Set<String>, onLike: (String) -> Unit, onProfile: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Para você", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Vídeos públicos de toda a comunidade", color = Muted, style = MaterialTheme.typography.bodySmall) }
                Surface(color = Color(0xFF231438), shape = RoundedCornerShape(30.dp)) { Text("PÚBLICO", Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Pink, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            }
        }
        items(clips) { clip ->
            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Box(Modifier.fillMaxWidth().height(205.dp).background(Brush.linearGradient(clip.colors)), contentAlignment = Alignment.Center) {
                        Text(clip.emoji, style = MaterialTheme.typography.displayLarge)
                        Surface(color = Color(0xAA050711), shape = RoundedCornerShape(30.dp), modifier = Modifier.align(Alignment.TopStart).padding(12.dp)) { Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PlayCircle, null, tint = Pink, modifier = Modifier.size(16.dp)); Text("  VÍDEO DE EXEMPLO", style = MaterialTheme.typography.labelSmall) } }
                        Text("▶", Modifier.align(Alignment.Center).clip(CircleShape).background(Color(0x88303050)).padding(horizontal = 18.dp, vertical = 12.dp), style = MaterialTheme.typography.headlineMedium)
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { onProfile() }) { Text(clip.creator, fontWeight = FontWeight.Bold); Text(clip.title, color = Muted, style = MaterialTheme.typography.bodySmall); Text("${clip.views} visualizações • público", color = Muted, style = MaterialTheme.typography.labelSmall) }
                        IconButton(onClick = { onLike(clip.creator) }) { Icon(Icons.Default.FavoriteBorder, contentDescription = "Curtir", tint = if (clip.creator in liked) Pink else Color.White) }
                        Text(if (clip.creator in liked) "Curtido" else "Curtir", color = if (clip.creator in liked) Pink else Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item { Text("Conteúdo ilustrativo: os vídeos acima são cartões de demonstração, não publicações reais. O feed público real será ligado ao armazenamento e às contas na próxima etapa.", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 12.dp)) }
    }
}

@Composable
private fun LivePage(onNotice: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Lives", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Encontre transmissões e configure destinos externos.", color = Muted)
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Começar uma live", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Câmera, microfone e transmissão ao vivo ainda precisam de integração com um servidor de mídia.", color = Muted)
            Button(onClick = { onNotice("Transmissão ainda não conectada: nenhum vídeo está sendo enviado.") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Radio, null); Spacer(Modifier.width(8.dp)); Text("Configurar transmissão") }
        } }
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Multiplataforma", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Destinos planejados", color = Muted)
            listOf("VYBORA — plataforma principal", "YouTube Live — integração pendente", "Twitch — integração pendente", "TikTok LIVE — acesso precisa ser validado", "KICK — integração pendente").forEach { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(if (it.startsWith("VYBORA")) Pink else Violet)); Text(it, Modifier.padding(start = 10.dp), style = MaterialTheme.typography.bodyMedium) } }
            OutlinedButton(onClick = { onNotice("Nenhuma conta externa foi conectada. As integrações só serão marcadas como ativas após testes reais.") }, modifier = Modifier.fillMaxWidth()) { Text("Ver status das integrações") }
        } }
    }
}

@Composable
private fun SimplePage(title: String, description: String, action: String, onAction: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
                Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(description, color = Muted)
                Button(onClick = onAction, modifier = Modifier.fillMaxWidth()) { Text(action) }
            }
        }
        Text("VYBORA • Protótipo Android", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}
