# Configurar o login Google do VYBORA

O código do login Google já está integrado no aplicativo e no backend. Para autenticar de verdade, é obrigatório criar um ID OAuth no Google Cloud. Não existe um ID universal que possamos colocar no código: ele pertence ao projeto do proprietário.

## 1. Criar credenciais no Google Cloud

1. Entre em https://console.cloud.google.com/ e crie/selecione um projeto para o VYBORA.
2. Configure a tela de consentimento OAuth e informe o nome do aplicativo e o e-mail de suporte. Durante testes, adicione as contas Google de teste.
3. Em APIs e serviços → Credenciais, crie um OAuth Client ID do tipo **Aplicativo da Web**.
4. Copie o Client ID que termina em `apps.googleusercontent.com`. Esse é o valor usado nos dois lados do VYBORA. Não é a chave secreta de cliente.
5. Para a integração Android/Google Identity, configure também o cliente OAuth Android quando o Google Cloud solicitar: pacote `app.vybora.android` e SHA-1 do certificado de assinatura usado para instalar o APK. Para ver o SHA-1 de debug, rode `./gradlew signingReport` na raiz do projeto.

## 2. Configurar o backend

Em `BACKEND/.env`, defina:

```env
GOOGLE_CLIENT_ID=SEU_CLIENT_ID_WEB.apps.googleusercontent.com
```

O backend deve usar o mesmo Client ID Web e verificar o ID token recebido. Não coloque `GOOGLE_CLIENT_SECRET`, senha de banco, JWT secret ou SMTP password no APK.

## 3. Compilar o APK com o ID correto

Na raiz `VYBORA/`, rode no mesmo terminal em que definiu o valor:

```bash
export GOOGLE_WEB_CLIENT_ID='SEU_CLIENT_ID_WEB.apps.googleusercontent.com'
./gradlew --no-daemon assembleDebug
```

Ou passe como propriedade Gradle:

```bash
./gradlew --no-daemon assembleDebug -PGOOGLE_WEB_CLIENT_ID='SEU_CLIENT_ID_WEB.apps.googleusercontent.com'
```

O APK de debug, se a compilação terminar com sucesso, ficará em `app/build/outputs/apk/debug/app-debug.apk`. Para autenticar, o backend também precisa estar executando, acessível pelo aparelho e configurado com o mesmo `GOOGLE_CLIENT_ID`.

## 4. Testar

- Instale o APK compilado com o ID configurado.
- Inicie o backend e confirme `GET /health`.
- Toque em “Continuar com Google”, selecione uma conta e confirme que o app recebe uma sessão válida.
- Teste com uma conta Google verificada e também cancele o seletor para confirmar o tratamento do cancelamento.
- Se aparecer `DEVELOPER_ERROR` ou `10`, confira tipo de cliente OAuth, pacote Android e SHA-1 do certificado que assinou esse APK.
- Se aparecer “Login Google ainda não configurado”, confira `GOOGLE_CLIENT_ID` no ambiente do backend.

## Limitação importante

O projeto não pode ativar login Google sem o Client ID criado na conta Google Cloud do proprietário. Esta configuração não pode ser inventada ou substituída por uma credencial genérica. O código compila sem o ID, mas o botão informa que o recurso não está configurado até que os valores corretos sejam fornecidos.
