# VYBORA Android + Backend 0.3.0

Projeto Android Kotlin/Jetpack Compose e API REST Node.js/Express com PostgreSQL local e armazenamento de mídias em disco controlado pelo backend. Render e Supabase não são necessários para desenvolvimento local.

## Conteúdo

- `app/`: aplicativo Android.
- `BACKEND/`: API Express, schema/migrações SQL, Docker Compose, armazenamento local e scripts de backup.
- `SUPABASE/`: arquivos antigos de referência; não fazem parte do caminho padrão de execução.
- `COMO_COMPILAR_E_TESTAR.txt`: instruções resumidas para preparar o backend e compilar o APK.

## Compilação Android

Requer JDK 17, Android SDK (plataforma 35) e acesso às dependências Gradle/Maven. Execute na raiz:

```bash
./gradlew --no-daemon assembleDebug
```

APK esperado: `app/build/outputs/apk/debug/app-debug.apk`.

Para compilar apontando para outra API local:

```bash
./gradlew --no-daemon assembleDebug -PAPI_BASE_URL=http://127.0.0.1:8080
```

No emulador Android com API no computador host, use `-PAPI_BASE_URL=http://10.0.2.2:8080`. Para build release, configure uma API HTTPS e não use HTTP local.

## Backend local

Consulte `BACKEND/README.md`. Em resumo: configure `BACKEND/.env`, inicie PostgreSQL, execute `npm install`, `npm run migrate` e `npm start`. Login Google exige credenciais OAuth; recuperação por e-mail exige SMTP.

## Estado de validação

Nesta revisão passaram as verificações de sintaxe JavaScript, sintaxe dos scripts de backup, teste de gravação/leitura/hash do armazenamento local e validação XML dos manifests. A compilação Gradle completa não pôde ser executada neste ambiente porque o DNS não conseguiu resolver `services.gradle.org`; execute o comando de compilação num ambiente com acesso à rede e Android SDK antes de distribuir o APK.

Não use com usuários reais até testar cadastro/login, publicação, exportação, backup externo e restauração completa.
