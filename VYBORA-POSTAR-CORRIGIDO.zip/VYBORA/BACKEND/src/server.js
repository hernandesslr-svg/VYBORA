import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import pg from 'pg';
import dotenv from 'dotenv';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { createUploadUrl, createDownloadUrl, inspectObject } from './storage.js';

dotenv.config();
const { Pool } = pg;
const app = express();
const port = Number(process.env.PORT || 8080);
const jwtSecret = process.env.JWT_SECRET || '';
if (jwtSecret.length < 32) throw new Error('JWT_SECRET precisa ter pelo menos 32 caracteres aleatórios.');
if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL não configurada.');
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_SSL === 'true' ? { rejectUnauthorized: true } : undefined, max: 15, idleTimeoutMillis: 30000 });
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN === '*' ? true : (process.env.CORS_ORIGIN || '').split(',').filter(Boolean), credentials: false }));
app.use(express.json({ limit: '64kb' }));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }));
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const tokenFor = user => jwt.sign({ sub: user.id }, jwtSecret, { expiresIn: '7d', issuer: 'vybora-api', audience: 'vybora-app' });
const safeUser = user => ({ id: user.id, username: user.username, email: user.email, displayName: user.display_name, bio: user.bio, avatarUrl: user.avatar_url, verified: user.is_verified, createdAt: user.created_at });
const auth = asyncRoute(async (req,res,next) => {
  const value = req.get('authorization') || '';
  if (!value.startsWith('Bearer ')) return res.status(401).json({ error: 'Faça login para continuar.' });
  let payload;
  try {
    payload = jwt.verify(value.slice(7), jwtSecret, { issuer: 'vybora-api', audience: 'vybora-app' });
  } catch {
    return res.status(401).json({ error: 'Sessão inválida ou expirada.' });
  }
  const { rows } = await pool.query('SELECT id, username, email, display_name, bio, avatar_url, is_verified, created_at FROM users WHERE id=$1', [payload.sub]);
  if (!rows[0]) return res.status(401).json({ error: 'Sessão inválida.' });
  req.user = rows[0]; next();
});
app.get('/health', asyncRoute(async (_req,res) => { await pool.query('SELECT 1'); res.json({ status: 'ok', service: 'vybora-api', database: 'connected' }); }));
app.post('/api/auth/register', asyncRoute(async (req,res) => {
  const username = String(req.body?.username || '').trim().toLowerCase();
  const email = String(req.body?.email || '').trim().toLowerCase();
  const password = String(req.body?.password || '');
  if (!/^[a-z0-9_.]{3,24}$/.test(username)) return res.status(400).json({ error: 'Nome de usuário inválido (3–24 letras, números, ponto ou sublinhado).' });
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: 'E-mail inválido.' });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: 'A senha deve ter entre 8 e 72 caracteres.' });
  const hash = await bcrypt.hash(password, 12);
  try {
    const { rows } = await pool.query('INSERT INTO users(username,email,password_hash) VALUES($1,$2,$3) RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at', [username,email,hash]);
    const user = rows[0]; res.status(201).json({ token: tokenFor(user), user: safeUser(user) });
  } catch (e) {
    if (e.code === '23505') return res.status(409).json({ error: 'Este e-mail ou nome de usuário já está cadastrado.' });
    throw e;
  }
}));
app.post('/api/auth/login', asyncRoute(async (req,res) => {
  const email = String(req.body?.email || '').trim().toLowerCase(); const password = String(req.body?.password || '');
  const { rows } = await pool.query('SELECT * FROM users WHERE email=$1', [email]);
  if (!rows[0] || !(await bcrypt.compare(password, rows[0].password_hash))) return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
  res.json({ token: tokenFor(rows[0]), user: safeUser(rows[0]) });
}));
app.get('/api/auth/me', auth, (req,res) => res.json({ user: safeUser(req.user) }));
app.patch('/api/users/me', auth, asyncRoute(async (req,res) => {
  const displayName = String(req.body?.displayName ?? req.user.display_name).trim().slice(0,80);
  const bio = String(req.body?.bio ?? req.user.bio).trim().slice(0,300);
  const { rows } = await pool.query('UPDATE users SET display_name=$1,bio=$2,updated_at=NOW() WHERE id=$3 RETURNING id,username,email,display_name,bio,avatar_url,is_verified,created_at', [displayName,bio,req.user.id]);
  res.json({ user: safeUser(rows[0]) });
}));
app.get('/api/users/:username', asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT u.id,u.username,u.display_name,u.bio,u.avatar_url,u.is_verified,u.created_at,
    (SELECT COUNT(*)::int FROM follows WHERE following_id=u.id) AS followers,
    (SELECT COUNT(*)::int FROM follows WHERE follower_id=u.id) AS following,
    (SELECT COUNT(*)::int FROM posts WHERE user_id=u.id) AS posts_count
    FROM users u WHERE u.username=$1`, [String(req.params.username).toLowerCase()]);
  if (!rows[0]) return res.status(404).json({ error: 'Usuário não encontrado.' }); res.json({ user: rows[0] });
}));
app.post('/api/users/:id/follow', auth, asyncRoute(async (req,res) => {
  const target = req.params.id; if (target === req.user.id) return res.status(400).json({ error: 'Você não pode seguir a si mesmo.' });
  const exists = await pool.query('SELECT id FROM users WHERE id=$1',[target]); if (!exists.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  const found = await pool.query('SELECT 1 FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.id,target]);
  if (found.rowCount) { await pool.query('DELETE FROM follows WHERE follower_id=$1 AND following_id=$2',[req.user.id,target]); return res.json({ following: false }); }
  await pool.query('INSERT INTO follows(follower_id,following_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,target]);
  await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind) VALUES($1,$2,'follow')",[target,req.user.id]);
  res.json({ following: true });
}));
app.get('/api/posts', asyncRoute(async (req,res) => {
  const limit = Math.min(Math.max(Number(req.query.limit || 20),1),50); const before = req.query.before ? String(req.query.before) : null;
  const { rows } = await pool.query(`SELECT p.id,p.caption,p.media_url AS "mediaUrl",p.media_type AS "mediaType",p.visibility,p.created_at AS "createdAt",
    json_build_object('id',u.id,'username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url,'verified',u.is_verified) AS author,
    (SELECT COUNT(*)::int FROM post_likes l WHERE l.post_id=p.id) AS likes,
    (SELECT COUNT(*)::int FROM comments c WHERE c.post_id=p.id) AS comments
    FROM posts p JOIN users u ON u.id=p.user_id WHERE p.visibility='public' AND ($2::timestamptz IS NULL OR p.created_at<$2)
    ORDER BY p.created_at DESC LIMIT $1`, [limit,before]); res.json({ posts: rows });
}));
app.post('/api/posts', auth, asyncRoute(async (req,res) => {
  const caption = String(req.body?.caption || '').trim(); const mediaUrl = req.body?.mediaUrl ? String(req.body.mediaUrl) : null;
  const mediaType = String(req.body?.mediaType || (mediaUrl ? 'image' : 'text'));
  if (!caption && !mediaUrl) return res.status(400).json({ error: 'Adicione texto ou mídia à publicação.' });
  if (caption.length > 2200) return res.status(400).json({ error: 'A legenda ultrapassa 2200 caracteres.' });
  if (!['text','image','video'].includes(mediaType)) return res.status(400).json({ error: 'Tipo de mídia inválido.' });
  if (mediaUrl && !/^https:\/\//i.test(mediaUrl)) return res.status(400).json({ error: 'A URL da mídia precisa usar HTTPS.' });
  const { rows } = await pool.query('INSERT INTO posts(user_id,caption,media_url,media_type) VALUES($1,$2,$3,$4) RETURNING id,caption,media_url AS "mediaUrl",media_type AS "mediaType",created_at AS "createdAt"',[req.user.id,caption,mediaUrl,mediaType]);
  res.status(201).json({ post: { ...rows[0], author: safeUser(req.user), likes: 0, comments: 0 } });
}));
app.post('/api/posts/:id/like', auth, asyncRoute(async (req,res) => {
  const post = await pool.query('SELECT id,user_id FROM posts WHERE id=$1',[req.params.id]); if (!post.rowCount) return res.status(404).json({ error: 'Publicação não encontrada.' });
  const found = await pool.query('SELECT 1 FROM post_likes WHERE user_id=$1 AND post_id=$2',[req.user.id,req.params.id]);
  if (found.rowCount) { await pool.query('DELETE FROM post_likes WHERE user_id=$1 AND post_id=$2',[req.user.id,req.params.id]); return res.json({ liked: false }); }
  await pool.query('INSERT INTO post_likes(user_id,post_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,req.params.id]);
  if (post.rows[0].user_id !== req.user.id) await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'like',$3)",[post.rows[0].user_id,req.user.id,req.params.id]);
  res.json({ liked: true });
}));
app.post('/api/posts/:id/comments', auth, asyncRoute(async (req,res) => {
  const body = String(req.body?.body || '').trim(); if (!body || body.length > 1200) return res.status(400).json({ error: 'O comentário deve ter de 1 a 1200 caracteres.' });
  const post = await pool.query('SELECT user_id FROM posts WHERE id=$1',[req.params.id]); if (!post.rowCount) return res.status(404).json({ error: 'Publicação não encontrada.' });
  const { rows } = await pool.query('INSERT INTO comments(post_id,user_id,body) VALUES($1,$2,$3) RETURNING id,post_id AS "postId",body,created_at AS "createdAt"',[req.params.id,req.user.id,body]);
  if (post.rows[0].user_id !== req.user.id) await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'comment',$3)",[post.rows[0].user_id,req.user.id,req.params.id]);
  res.status(201).json({ comment: { ...rows[0], author: safeUser(req.user) } });
}));
app.get('/api/posts/:id/comments', asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT c.id,c.body,c.created_at AS "createdAt",json_build_object('id',u.id,'username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url) AS author FROM comments c JOIN users u ON u.id=c.user_id WHERE c.post_id=$1 ORDER BY c.created_at ASC LIMIT 100`,[req.params.id]); res.json({ comments: rows });
}));
app.get('/api/messages/:username', auth, asyncRoute(async (req,res) => {
  const other = await pool.query('SELECT id FROM users WHERE username=$1',[String(req.params.username).toLowerCase()]); if (!other.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  const { rows } = await pool.query(`SELECT m.id,m.body,m.created_at AS "createdAt",m.read_at AS "readAt",m.sender_id AS "senderId",m.recipient_id AS "recipientId" FROM messages m WHERE (m.sender_id=$1 AND m.recipient_id=$2) OR (m.sender_id=$2 AND m.recipient_id=$1) ORDER BY m.created_at ASC LIMIT 200`,[req.user.id,other.rows[0].id]);
  await pool.query('UPDATE messages SET read_at=NOW() WHERE sender_id=$1 AND recipient_id=$2 AND read_at IS NULL',[other.rows[0].id,req.user.id]); res.json({ messages: rows });
}));
app.post('/api/messages/:username', auth, asyncRoute(async (req,res) => {
  const body = String(req.body?.body || '').trim(); if (!body || body.length > 5000) return res.status(400).json({ error: 'A mensagem deve ter de 1 a 5000 caracteres.' });
  const recipient = await pool.query('SELECT id FROM users WHERE username=$1',[String(req.params.username).toLowerCase()]); if (!recipient.rowCount) return res.status(404).json({ error: 'Usuário não encontrado.' });
  if (recipient.rows[0].id === req.user.id) return res.status(400).json({ error: 'Não é possível enviar mensagem para si mesmo.' });
  const { rows } = await pool.query('INSERT INTO messages(sender_id,recipient_id,body) VALUES($1,$2,$3) RETURNING id,body,created_at AS "createdAt",sender_id AS "senderId",recipient_id AS "recipientId"',[req.user.id,recipient.rows[0].id,body]);
  await pool.query("INSERT INTO notifications(recipient_id,actor_id,kind,entity_id) VALUES($1,$2,'message',$3)",[recipient.rows[0].id,req.user.id,rows[0].id]); res.status(201).json({ message: rows[0] });
}));
// Dados privados opcionais da própria conta; nunca fazem parte do perfil público.
app.get('/api/users/me/private-profile', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query('SELECT birth_date AS "birthDate",phone_e164 AS "phone",country_code AS "countryCode",locale,updated_at AS "updatedAt" FROM user_private_profiles WHERE user_id=$1',[req.user.id]);
  res.json({ privateProfile: rows[0] || { birthDate: null, phone: null, countryCode: null, locale: null } });
}));
app.patch('/api/users/me/private-profile', auth, asyncRoute(async (req,res) => {
  const birthDate = req.body?.birthDate ? String(req.body.birthDate) : null;
  const phone = req.body?.phone ? String(req.body.phone).trim().slice(0,20) : null;
  const countryCode = req.body?.countryCode ? String(req.body.countryCode).trim().toUpperCase() : null;
  const locale = req.body?.locale ? String(req.body.locale).trim().slice(0,20) : null;
  if (birthDate && !/^\d{4}-\d{2}-\d{2}$/.test(birthDate)) return res.status(400).json({ error: 'Data de nascimento inválida; use AAAA-MM-DD.' });
  if (countryCode && !/^[A-Z]{2}$/.test(countryCode)) return res.status(400).json({ error: 'Código do país inválido.' });
  const { rows } = await pool.query(`INSERT INTO user_private_profiles(user_id,birth_date,phone_e164,country_code,locale,updated_at)
    VALUES($1,$2,$3,$4,$5,NOW()) ON CONFLICT(user_id) DO UPDATE SET birth_date=EXCLUDED.birth_date,phone_e164=EXCLUDED.phone_e164,country_code=EXCLUDED.country_code,locale=EXCLUDED.locale,updated_at=NOW()
    RETURNING birth_date AS "birthDate",phone_e164 AS "phone",country_code AS "countryCode",locale,updated_at AS "updatedAt"`,[req.user.id,birthDate,phone,countryCode,locale]);
  res.json({ privateProfile: rows[0] });
}));

// Exportação portátil dos dados da própria conta em JSON (LGPD/data portability).
app.get('/api/users/me/export', auth, asyncRoute(async (req,res) => {
  const id = req.user.id;
  const queries = await Promise.all([
    pool.query('SELECT id,username,email,display_name,bio,avatar_url,is_verified,created_at,updated_at FROM users WHERE id=$1',[id]),
    pool.query('SELECT birth_date,phone_e164,country_code,locale,updated_at FROM user_private_profiles WHERE user_id=$1',[id]),
    pool.query('SELECT id,caption,media_url,media_type,visibility,created_at FROM posts WHERE user_id=$1 ORDER BY created_at',[id]),
    pool.query('SELECT l.post_id,l.created_at FROM post_likes l WHERE l.user_id=$1 ORDER BY l.created_at',[id]),
    pool.query('SELECT f.following_id,f.created_at FROM follows f WHERE f.follower_id=$1 ORDER BY f.created_at',[id]),
    pool.query('SELECT c.id,c.post_id,c.body,c.created_at FROM comments c WHERE c.user_id=$1 ORDER BY c.created_at',[id]),
    pool.query('SELECT id,sender_id,recipient_id,body,read_at,created_at FROM messages WHERE sender_id=$1 OR recipient_id=$1 ORDER BY created_at',[id]),
    pool.query("SELECT id,category,original_name,content_type,size_bytes,created_at FROM user_files WHERE owner_id=$1 AND deleted_at IS NULL AND status='ready' ORDER BY created_at",[id]),
    pool.query('SELECT id,kind,entity_id,read_at,created_at FROM notifications WHERE recipient_id=$1 ORDER BY created_at',[id])
  ]);
  res.set('Content-Disposition', 'attachment; filename="vybora-dados-pessoais.json"');
  res.json({ formatVersion: 1, exportedAt: new Date().toISOString(), profile: queries[0].rows[0], privateProfile: queries[1].rows[0] || null, posts: queries[2].rows, likes: queries[3].rows, following: queries[4].rows, comments: queries[5].rows, messages: queries[6].rows, files: queries[7].rows, notifications: queries[8].rows });
}));

// Uploads use a private bucket, short-lived URLs, declared size limits and an explicit completion check.
app.post('/api/files/upload-url', auth, asyncRoute(async (req,res) => {
  const originalName = String(req.body?.fileName || '').trim().split(/[\\/]/).pop();
  const contentType = String(req.body?.contentType || '').toLowerCase();
  const category = String(req.body?.category || 'attachment');
  const sizeBytes = Number(req.body?.sizeBytes);
  const allowedTypes = new Set(['image/jpeg','image/png','image/webp','image/gif','video/mp4','video/webm','application/pdf']);
  const maxBytes = category === 'post_media' && contentType.startsWith('video/') ? 100 * 1024 * 1024 : 25 * 1024 * 1024;
  if (!originalName || originalName.length > 255) return res.status(400).json({ error: 'Nome de arquivo inválido.' });
  if (!allowedTypes.has(contentType)) return res.status(415).json({ error: 'Tipo de arquivo não permitido.' });
  if (!['avatar','post_media','document','attachment'].includes(category)) return res.status(400).json({ error: 'Categoria inválida.' });
  if (!Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > maxBytes) return res.status(413).json({ error: `Arquivo inválido ou maior que o limite de ${Math.floor(maxBytes / 1024 / 1024)} MB.` });
  const key = `users/${req.user.id}/${randomUUID()}`;
  const uploadUrl = await createUploadUrl(key, contentType, sizeBytes);
  const { rows } = await pool.query("INSERT INTO user_files(owner_id,category,original_name,content_type,object_key,expected_size_bytes,status) VALUES($1,$2,$3,$4,$5,$6,'pending') RETURNING id,category,original_name AS \"fileName\",content_type AS \"contentType\",expected_size_bytes AS \"expectedSizeBytes\",status,created_at AS \"createdAt\"",[req.user.id,category,originalName,contentType,key,sizeBytes]);
  res.status(201).json({ file: rows[0], uploadUrl, method: 'PUT', expiresInSeconds: 300, requiredHeaders: { 'Content-Type': contentType, 'Content-Length': String(sizeBytes) }, completionRequired: true });
}));
app.post('/api/files/:id/complete', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query('SELECT id,object_key,content_type,expected_size_bytes,status FROM user_files WHERE id=$1 AND owner_id=$2 AND deleted_at IS NULL',[req.params.id,req.user.id]);
  const file = rows[0];
  if (!file) return res.status(404).json({ error: 'Arquivo não encontrado.' });
  if (file.status === 'ready') return res.json({ ok: true, status: 'ready' });
  const object = await inspectObject(file.object_key);
  if (object.sizeBytes !== Number(file.expected_size_bytes) || object.contentType !== file.content_type) {
    return res.status(422).json({ error: 'O arquivo enviado não corresponde ao tamanho ou tipo declarado. Ele não foi liberado para uso.' });
  }
  const updated = await pool.query("UPDATE user_files SET size_bytes=$1,checksum_sha256=$2,object_etag=$3,object_version_id=$4,status='ready',uploaded_at=NOW() WHERE id=$5 AND owner_id=$6 AND status='pending' RETURNING id,category,original_name AS \"fileName\",content_type AS \"contentType\",size_bytes AS \"sizeBytes\",checksum_sha256 AS \"checksumSha256\",status,uploaded_at AS \"uploadedAt\"",[object.sizeBytes,object.checksumSha256,object.etag,object.versionId,file.id,req.user.id]);
  res.json({ ok: true, file: updated.rows[0] || { id: file.id, status: 'ready' } });
}));
app.get('/api/files', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query("SELECT id,category,original_name AS \"fileName\",content_type AS \"contentType\",size_bytes AS \"sizeBytes\",status,uploaded_at AS \"uploadedAt\",created_at AS \"createdAt\" FROM user_files WHERE owner_id=$1 AND deleted_at IS NULL AND status='ready' ORDER BY created_at DESC LIMIT 200",[req.user.id]);
  res.json({ files: rows });
}));
app.get('/api/files/:id/download-url', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query("SELECT object_key FROM user_files WHERE id=$1 AND owner_id=$2 AND deleted_at IS NULL AND status='ready'",[req.params.id,req.user.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Arquivo não encontrado.' });
  res.json({ downloadUrl: await createDownloadUrl(rows[0].object_key), expiresInSeconds: 120 });
}));
app.delete('/api/files/:id', auth, asyncRoute(async (req,res) => {
  // Soft-delete first; a separate retention job can remove the object after recovery window.
  const result = await pool.query('UPDATE user_files SET deleted_at=NOW() WHERE id=$1 AND owner_id=$2 AND deleted_at IS NULL',[req.params.id,req.user.id]);
  if (!result.rowCount) return res.status(404).json({ error: 'Arquivo não encontrado.' });
  res.status(204).end();
}));
app.post('/api/files/:id/restore', auth, asyncRoute(async (req,res) => {
  // Restore only metadata; object existence is checked before re-enabling access.
  const { rows } = await pool.query("SELECT object_key,content_type,size_bytes FROM user_files WHERE id=$1 AND owner_id=$2 AND deleted_at IS NOT NULL AND status='ready'",[req.params.id,req.user.id]);
  if (!rows[0]) return res.status(404).json({ error: 'Arquivo recuperável não encontrado.' });
  const object = await inspectObject(rows[0].object_key);
  if (object.sizeBytes !== Number(rows[0].size_bytes) || object.contentType !== rows[0].content_type) return res.status(409).json({ error: 'O arquivo armazenado não passou na verificação de integridade.' });
  await pool.query('UPDATE user_files SET deleted_at=NULL WHERE id=$1 AND owner_id=$2',[req.params.id,req.user.id]);
  res.json({ ok: true, restored: true });
}));

app.get('/api/notifications', auth, asyncRoute(async (req,res) => {
  const { rows } = await pool.query(`SELECT n.id,n.kind,n.entity_id AS "entityId",n.read_at AS "readAt",n.created_at AS "createdAt",json_build_object('username',u.username,'displayName',u.display_name,'avatarUrl',u.avatar_url) AS actor FROM notifications n LEFT JOIN users u ON u.id=n.actor_id WHERE n.recipient_id=$1 ORDER BY n.created_at DESC LIMIT 100`,[req.user.id]); res.json({ notifications: rows });
}));
app.post('/api/notifications/read', auth, asyncRoute(async (req,res) => { await pool.query('UPDATE notifications SET read_at=NOW() WHERE recipient_id=$1 AND read_at IS NULL',[req.user.id]); res.json({ ok: true }); }));
app.use((req,res) => res.status(404).json({ error: 'Rota não encontrada.' }));
app.use((err,req,res,_next) => { console.error('API error:', err?.message || err); res.status(500).json({ error: process.env.NODE_ENV === 'production' ? 'Erro interno do servidor.' : (err?.message || 'Erro interno.') }); });
// Banco atualizado explicitamente com `npm run migrate` durante o deploy;
// a API não altera o schema automaticamente ao iniciar.

app.listen(port, '0.0.0.0', () => console.log(`VYBORA API listening on ${port}`));
process.on('SIGTERM', async () => { await pool.end(); process.exit(0); });
process.on('SIGINT', async () => { await pool.end(); process.exit(0); });
