import SwiftUI
import PhotosUI
import UIKit

@main
struct VyboraApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct ContentView: View {
    @State private var tab = 1
    @State private var notice = ""
    @State private var caption = ""
    @State private var selectedPhoto: PhotosPickerItem?
    @State private var pickedImage: Image?
    private let bg = Color(red: 5/255, green: 7/255, blue: 17/255)
    private let panel = Color(red: 17/255, green: 21/255, blue: 40/255)
    private let violet = Color(red: 139/255, green: 53/255, blue: 1)
    private let pink = Color(red: 1, green: 42/255, blue: 157/255)
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 11) {
                Text("V").font(.title.bold()).frame(width: 40, height: 40)
                    .background(LinearGradient(colors: [violet,pink], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .clipShape(RoundedRectangle(cornerRadius: 13))
                VStack(alignment: .leading, spacing: 2) {
                    Text("VYBORA").font(.system(.title3, design: .default).weight(.black)).tracking(3)
                    Text("Lives e vídeos curtos. Pra todo mundo.").font(.caption2).foregroundStyle(.gray)
                }
                Spacer()
                Image(systemName: "magnifyingglass").font(.title3)
            }.padding()
            if !notice.isEmpty {
                HStack { Text(notice).font(.footnote); Spacer(); Button("×") { notice = "" } }
                    .padding(12).background(Color.purple.opacity(0.25)).clipShape(RoundedRectangle(cornerRadius: 12)).padding(.horizontal)
            }
            ScrollView {
                switch tab {
                case 0:
                    page("Seu mundo, sem limites.", "Descubra criadores, acompanhe as lives e encontre novos vídeos.")
                case 1:
                    messages
                case 2:
                    post
                case 3:
                    page("Lives", "As transmissões ao vivo serão exibidas quando o serviço de lives estiver conectado.")
                default:
                    page("Seu perfil", "Entre para acessar seu perfil.")
                }
            }
            HStack {
                nav("house", "Início", 0)
                nav("bubble.left.and.bubble.right", "Mensagens", 1)
                nav("plus.circle.fill", "Publicar", 2)
                nav("dot.radiowaves.left.and.right", "Lives", 3)
                nav("person.crop.circle", "Perfil", 4)
            }.padding(.top,10).padding(.bottom,6).background(Color(red: 8/255, green: 11/255, blue: 22/255))
        }.foregroundStyle(.white).background(bg.ignoresSafeArea())
    }
    func nav(_ icon:String,_ title:String,_ value:Int)->some View {
        Button { tab = value } label: {
            VStack(spacing:5) { Image(systemName: icon).font(.system(size:20)); Text(title).font(.system(size:10)) }
                .foregroundStyle(tab == value ? pink : .gray).frame(maxWidth:.infinity)
        }
    }
    func page(_ title:String,_ subtitle:String)->some View {
        VStack(alignment:.leading,spacing:12) {
            Text(title).font(.title.bold())
            Text(subtitle).foregroundStyle(.gray)
            RoundedRectangle(cornerRadius:18).fill(LinearGradient(colors:[violet.opacity(0.55),pink.opacity(0.25)],startPoint:.topLeading,endPoint:.bottomTrailing))
                .frame(height:180).overlay(Text("VYBORA").font(.system(.largeTitle, design: .default).weight(.black)).tracking(4))
        }.padding(20)
    }
    var messages: some View {
        VStack(alignment:.leading,spacing:14) {
            Text("Mensagens").font(.title.bold())
            Text("Suas conversas aparecerão aqui quando o serviço de mensagens estiver conectado.").foregroundStyle(.gray)
            ForEach(["Comunidade Vybora","Criadores em destaque","Suporte Vybora"],id:\.self) { name in
                HStack {
                    Image(systemName:"person.crop.circle.fill").font(.largeTitle).foregroundStyle(violet)
                    VStack(alignment:.leading) { Text(name).bold(); Text("Comece uma nova conversa").font(.caption).foregroundStyle(.gray) }
                    Spacer()
                }.padding().background(panel).clipShape(RoundedRectangle(cornerRadius:14))
            }
        }.padding()
    }
    var post: some View {
        VStack(alignment:.leading,spacing:16) {
            Text("Criar publicação").font(.title.bold())
            PhotosPicker(selection:$selectedPhoto,matching:.images) {
                ZStack { RoundedRectangle(cornerRadius:16).fill(panel).frame(height:210)
                    if let pickedImage { pickedImage.resizable().scaledToFit().frame(height:200) }
                    else { VStack { Image(systemName:"photo.badge.plus").font(.system(size:40)); Text("Escolher foto").bold() }.foregroundStyle(pink) }
                }
            }.onChange(of: selectedPhoto) { item in
                Task { if let data = try? await item?.loadTransferable(type:Data.self), let ui = UIImage(data:data) { pickedImage = Image(uiImage:ui) } }
            }
            TextField("Escreva uma legenda...",text:$caption,axis:.vertical).lineLimit(3...6).padding().background(panel).clipShape(RoundedRectangle(cornerRadius:12))
            Button { notice = "A publicação será enviada quando o servidor Vybora estiver conectado." } label: {
                Text("Publicar").bold().frame(maxWidth:.infinity).padding().background(LinearGradient(colors:[violet,pink],startPoint:.leading,endPoint:.trailing)).clipShape(RoundedRectangle(cornerRadius:12))
            }
            Text("A versão iOS já inclui uma interface nativa inicial. Login real, busca global, mensagens e envio de mídia precisam de um backend compartilhado.").font(.caption).foregroundStyle(.gray)
        }.padding()
    }
}
