package app.vybora.android

import android.os.Bundle
import android.content.Context
import java.security.MessageDigest
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF050711)
private val Panel = Color(0xFF111528)
private val Violet = Color(0xFF8B35FF)
private val Pink = Color(0xFFFF2A9D)
private val Muted = Color(0xFFADB2CB)

private data class ClipItem(val creator: String, val title: String, val views: String, val emoji: String, val colors: List<Color>)
private val clips = listOf(
    ClipItem("@mundoselvagem", "Lugares que parecem outro planeta", "12,4 mil", "🏞️", listOf(Color(0xFFEC8A9D), Color(0xFF334F8A))),
    ClipItem("@darkvibes", "Ranked com a galera!", "8,7 mil", "🎮", listOf(Color(0xFF6518A8), Color(0xFF102A72))),
    ClipItem("@cozinhadalu", "Receita rápida de hoje", "5,3 mil", "🍜", listOf(Color(0xFFFF8B55), Color(0xFF8B255F))),
    ClipItem("@gatodigital", "Olha quem apareceu 😂", "3,9 mil", "🐱", listOf(Color(0xFFCA9D72), Color(0xFF4B355E)))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VyboraApp() }
    }
}

@Composable
private fun VyboraApp() {
    var tab by remember { mutableIntStateOf(1) }
    var liked by remember { mutableStateOf(setOf<String>()) }
    var notice by remember { mutableStateOf("") }
    var profileStat by remember { mutableStateOf("") }
    var showAuth by remember { mutableStateOf(false) }
    var loggedInUser by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Pink, background = Night, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Scaffold(containerColor = Night, bottomBar = {
            NavigationBar(containerColor = Color(0xFF080B16), contentColor = Color.White) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Início") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.ChatBubbleOutline, contentDescription = "Mensagens") }, label = { Text("Mensagens") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2; notice = "Publicação: a seleção e o envio de vídeos serão conectados na próxima etapa." }, icon = { Icon(Icons.Default.Add, null) }, label = { Text("Publicar") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Radio, null) }, label = { Text("Lives") })
                NavigationBarItem(selected = tab == 4, onClick = { tab = 4 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Perfil") })
            }
        }) { pad ->
            Column(Modifier.fillMaxSize().padding(pad)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", fontWeight = FontWeight.Black, style = MaterialTheme.typography.headlineSmall) }
                    Column(Modifier.padding(start = 10.dp).weight(1f)) {
                        Text("VYBORA", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("Lives e vídeos curtos. Pra todo mundo.", style = MaterialTheme.typography.labelSmall, color = Muted)
                    }
                    Icon(Icons.Default.Search, contentDescription = "Buscar", tint = Color.White, modifier = Modifier.size(25.dp).clickable { notice = "Busca global será conectada quando houver backend." })
                }
                if (notice.isNotBlank()) {
                    Surface(color = Color(0xFF25143A), shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Text(notice, Modifier.weight(1f), color = Color.White, style = MaterialTheme.typography.bodySmall); Text("×", Modifier.clickable { notice = "" }.padding(start = 12.dp), color = Pink) }
                    }
                }
                when (tab) {
                    0 -> SimplePage("Seu mundo, sem limites.", "Descubra criadores, acompanhe as lives e encontre novos vídeos.", "Explorar vídeos") { tab = 1 }
                    1 -> MessagesPage(onOpenMessage = { name -> notice = "Conversa com $name: mensagens reais serão ativadas quando as contas e o serviço de mensagens forem conectados." })
                    2 -> PostPage(onNotice = { notice = it })
                    3 -> LivePage(onNotice = { notice = it })
                    else -> if (showAuth) {
                        AuthPage(
                            onSuccess = { username -> loggedInUser = username; showAuth = false; notice = "Login realizado com sucesso!" },
                            onCancel = { showAuth = false }
                        )
                    } else ProfilePage(username = loggedInUser, onNotice = { notice = it }, onStat = { profileStat = it }, onAuth = { showAuth = true })
                }
            }
        }
        if (profileStat.isNotBlank()) {
            AlertDialog(
                onDismissRequest = { profileStat = "" },
                title = { Text(profileStat) },
                text = { Text(if (profileStat == "Seguidores") "Ainda não há seguidores reais. A lista aparecerá aqui quando as contas e o backend forem conectados." else if (profileStat == "Seguindo") "Você ainda não segue nenhuma conta nesta versão de demonstração." else "Ainda não há publicações reais nesta conta.") },
                confirmButton = { TextButton(onClick = { profileStat = "" }) { Text("Fechar") } }
            )
        }
    }
}


@Composable
private fun MessagesPage(onOpenMessage: (String) -> Unit) {
    val conversations = listOf(
        Triple("darkvibes", "Você viu a live de ontem?", "Agora"),
        Triple("mundoselvagem", "Te mandei aquele vídeo!", "12 min"),
        Triple("cozinhadalu", "Obrigada por acompanhar 😊", "1 h"),
        Triple("gameplus", "Bora jogar mais tarde?", "Ontem")
    )

    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text("Mensagens", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Suas conversas com a comunidade", color = Muted, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
        if (conversations.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Você ainda não tem mensagens.", color = Muted)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(conversations) { conversation ->
                    Surface(
                        color = Panel,
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onOpenMessage(conversation.first) }
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) {
                                Text(conversation.first.take(1).uppercase(), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                            }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text("@${conversation.first}", fontWeight = FontWeight.Bold, color = Color.White)
                                Text(conversation.second, color = Muted, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                            }
                            Text(conversation.third, color = Muted, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
            Text("Conversas ilustrativas: o envio e o recebimento de mensagens serão conectados na próxima etapa.", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(top = 12.dp))
        }
    }
}

@Composable
private fun ProfilePage(username: String, onNotice: (String) -> Unit, onStat: (String) -> Unit, onAuth: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Seu perfil", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(76.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black) }
                Text(if (username.isBlank()) "@seu_usuario" else "@$username", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text(if (username.isBlank()) "Entre ou crie sua conta" else "Conta conectada neste aparelho", color = Muted)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    ProfileStat("Publicações", "0") { onStat("Publicações") }
                    ProfileStat("Seguidores", "0") { onStat("Seguidores") }
                    ProfileStat("Seguindo", "0") { onStat("Seguindo") }
                }
                Button(onClick = { onNotice("Editar perfil ficará disponível após a implementação de cadastro e armazenamento de conta.") }, modifier = Modifier.fillMaxWidth()) { Text("Editar perfil") }
                OutlinedButton(onClick = onAuth, modifier = Modifier.fillMaxWidth()) { Text(if (username.isBlank()) "Entrar / criar conta" else "Trocar conta") }
            }
        }
        Text("Toque em Seguidores ou Seguindo para abrir a respectiva lista. Nesta base, as listas ainda não contêm usuários reais.", color = Muted, style = MaterialTheme.typography.bodySmall)
    }
}

private fun passwordDigest(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }

@Composable
private fun AuthPage(onSuccess: (String) -> Unit, onCancel: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("vybora_local_accounts", Context.MODE_PRIVATE) }
    var createAccount by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (createAccount) "Criar conta" else "Entrar na VYBORA", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("A conta fica salva neste aparelho. Ainda não é uma conta online.", color = Muted, style = MaterialTheme.typography.bodySmall)
        if (createAccount) OutlinedTextField(value = username, onValueChange = { username = it.trim().replace(" ", "") }, label = { Text("Nome de usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = email, onValueChange = { email = it.trim() }, label = { Text("E-mail") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Senha (mínimo 6 caracteres)") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        if (error.isNotBlank()) Text(error, color = Pink, style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val normalizedEmail = email.trim().lowercase()
            when {
                !normalizedEmail.contains("@") || !normalizedEmail.substringAfter("@", "").contains(".") -> error = "Digite um e-mail válido."
                password.length < 6 -> error = "A senha precisa ter pelo menos 6 caracteres."
                createAccount && username.trim().length < 3 -> error = "O nome de usuário precisa ter 3 caracteres ou mais."
                createAccount && prefs.contains("account_$normalizedEmail") -> error = "Já existe uma conta local com esse e-mail."
                createAccount -> {
                    val user = username.trim().lowercase()
                    prefs.edit().putString("account_$normalizedEmail", "${user}|${passwordDigest(password)}").apply()
                    onSuccess(user)
                }
                else -> {
                    val saved = prefs.getString("account_$normalizedEmail", null)
                    val parts = saved?.split("|", limit = 2)
                    if (parts != null && parts.size == 2 && parts[1] == passwordDigest(password)) onSuccess(parts[0])
                    else error = "E-mail ou senha incorretos. Se ainda não tem conta, toque em criar conta."
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (createAccount) "Criar conta" else "Entrar") }
        TextButton(onClick = { createAccount = !createAccount; error = "" }, modifier = Modifier.fillMaxWidth()) { Text(if (createAccount) "Já tenho conta — entrar" else "Não tenho conta — criar agora") }
        OutlinedButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Voltar ao perfil") }
    }
}

@Composable
private fun ProfileStat(label: String, count: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 10.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(count, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Pink)
        Text(label, style = MaterialTheme.typography.labelMedium, color = Color.White)
    }
}

@Composable
private fun VideoFeed(liked: Set<String>, onLike: (String) -> Unit, onProfile: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("Para você", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Vídeos públicos de toda a comunidade", color = Muted, style = MaterialTheme.typography.bodySmall) }
                Surface(color = Color(0xFF231438), shape = RoundedCornerShape(30.dp)) { Text("PÚBLICO", Modifier.padding(horizontal = 11.dp, vertical = 7.dp), color = Pink, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold) }
            }
        }
        items(clips) { clip ->
            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column {
                    Box(Modifier.fillMaxWidth().height(205.dp).background(Brush.linearGradient(clip.colors)), contentAlignment = Alignment.Center) {
                        Text(clip.emoji, style = MaterialTheme.typography.displayLarge)
                        Surface(color = Color(0xAA050711), shape = RoundedCornerShape(30.dp), modifier = Modifier.align(Alignment.TopStart).padding(12.dp)) { Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.PlayCircle, null, tint = Pink, modifier = Modifier.size(16.dp)); Text("  VÍDEO DE EXEMPLO", style = MaterialTheme.typography.labelSmall) } }
                        Text("▶", Modifier.align(Alignment.Center).clip(CircleShape).background(Color(0x88303050)).padding(horizontal = 18.dp, vertical = 12.dp), style = MaterialTheme.typography.headlineMedium)
                    }
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { onProfile() }) { Text(clip.creator, fontWeight = FontWeight.Bold); Text(clip.title, color = Muted, style = MaterialTheme.typography.bodySmall); Text("${clip.views} visualizações • público", color = Muted, style = MaterialTheme.typography.labelSmall) }
                        IconButton(onClick = { onLike(clip.creator) }) { Icon(Icons.Default.FavoriteBorder, contentDescription = "Curtir", tint = if (clip.creator in liked) Pink else Color.White) }
                        Text(if (clip.creator in liked) "Curtido" else "Curtir", color = if (clip.creator in liked) Pink else Muted, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        item { Text("Conteúdo ilustrativo: os vídeos acima são cartões de demonstração, não publicações reais. O feed público real será ligado ao armazenamento e às contas na próxima etapa.", color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(bottom = 12.dp)) }
    }
}

@Composable
private fun PostPage(onNotice: (String) -> Unit) {
    var caption by remember { mutableStateOf("") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedType by remember { mutableStateOf("") }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { selectedUri = uri; selectedType = "vídeo" }
    }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { selectedUri = uri; selectedType = "foto" }
    }

    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Criar publicação", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Escolha uma foto ou vídeo e escreva uma legenda.", color = Muted)
        OutlinedTextField(
            value = caption,
            onValueChange = { caption = it },
            label = { Text("Escreva uma legenda") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 3
        )
        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    selectedUri?.let { "Arquivo selecionado: $selectedType\n${it.lastPathSegment ?: "arquivo escolhido"}" }
                        ?: "Nenhum arquivo selecionado",
                    color = if (selectedUri != null) Color.White else Muted,
                    style = MaterialTheme.typography.bodyMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.weight(1f)) {
                        Text("Escolher foto")
                    }
                    OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.weight(1f)) {
                        Text("Escolher vídeo")
                    }
                }
            }
        }
        Button(
            onClick = {
                when {
                    selectedUri == null -> onNotice("Escolha uma foto ou vídeo antes de continuar.")
                    caption.isBlank() -> onNotice("Escreva uma legenda para a publicação.")
                    else -> onNotice("Publicação preparada com legenda e arquivo selecionado. O envio para outros usuários ainda precisa de um servidor de upload.")
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Preparar publicação")
        }
        Text(
            "Nesta versão, o seletor de mídia e a validação funcionam no aparelho. Para publicar e aparecer no feed de outras pessoas, falta conectar o armazenamento online.",
            color = Muted,
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun LivePage(onNotice: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Lives", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Encontre transmissões e configure destinos externos.", color = Muted)
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Começar uma live", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Câmera, microfone e transmissão ao vivo ainda precisam de integração com um servidor de mídia.", color = Muted)
            Button(onClick = { onNotice("Transmissão ainda não conectada: nenhum vídeo está sendo enviado.") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Radio, null); Spacer(Modifier.width(8.dp)); Text("Configurar transmissão") }
        } }
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Multiplataforma", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text("Destinos planejados", color = Muted)
            listOf("VYBORA — plataforma principal", "YouTube Live — integração pendente", "Twitch — integração pendente", "TikTok LIVE — acesso precisa ser validado", "KICK — integração pendente").forEach { Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).clip(CircleShape).background(if (it.startsWith("VYBORA")) Pink else Violet)); Text(it, Modifier.padding(start = 10.dp), style = MaterialTheme.typography.bodyMedium) } }
            OutlinedButton(onClick = { onNotice("Nenhuma conta externa foi conectada. As integrações só serão marcadas como ativas após testes reais.") }, modifier = Modifier.fillMaxWidth()) { Text("Ver status das integrações") }
        } }
    }
}

@Composable
private fun SimplePage(title: String, description: String, action: String, onAction: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Surface(color = Panel, shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(Brush.linearGradient(listOf(Violet, Pink))), contentAlignment = Alignment.Center) { Text("V", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black) }
                Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text(description, color = Muted)
                Button(onClick = onAction, modifier = Modifier.fillMaxWidth()) { Text(action) }
            }
        }
        Text("VYBORA • Protótipo Android", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}
